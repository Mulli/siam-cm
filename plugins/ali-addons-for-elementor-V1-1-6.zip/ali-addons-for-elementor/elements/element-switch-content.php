<?php

class Ali_sw extends \Elementor\Widget_Base {

    public function get_name() {
        return 'ali-switch-content';
    }

    public function get_title() {
        return __( 'Ali Switch Content', 'ali' );
    }

    public function get_icon() {
        return 'eicon-dual-button';
    }


    public function get_keywords() {
        return [ 'switch', 'content' ];
    }

    public function get_categories() {
        return [ 'ali-widgets' ];
    }
    public function get_script_depends() {
        return [
            'ali-sw-script'
        ];
    }

    public function get_style_depends() {
        return [
            'ali-sw-style'
        ];
    }

    protected function _register_controls() {
        $this->start_controls_section(
            'ali_sw_primary_section',
            [
                'label' => __( 'Section 1', 'ali' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'ali_sw_primary_label',
            [
                'label' => __( 'Title', 'ali' ),
                'type' => \Elementor\Controls_Manager::TEXT,

            ]
        );

        $this->add_control(
            'ali_sw_primary_content_type',
            [
                'label' => __( 'Type', 'ali' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'content',
                'options' => [
                    'image'  => __( 'Image','ali' ),
                    'content' => __( 'Text Editor','ali' ),
                    'saved_template' => __( 'Elementor Template','ali' ),
                ],
            ]
        );

        $this->add_control(
            'ali_sw_primary_content_wysiwyg',
            [
                'label' => __( 'Text Editor','ali' ),
                'type' => \Elementor\Controls_Manager::WYSIWYG,
                'condition' => [
                    'ali_sw_primary_content_type' => 'content'
                ]
            ]
        );

        $this->add_control(
            'ali_sw_primary_content_image',
            [
                'label' => __( 'Choose Image', 'ali' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'ali_sw_primary_content_type' => 'image'
                ]
            ]
        );

        $this->add_control(
            'ali_sw_primary_content_saved_template',
            [
                'label' => __( 'Shortcode', 'ali' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => __( 'Shortcode', 'ali' ),
                'condition' => [
                    'ali_sw_primary_content_type' => 'saved_template'
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'ali_sw_secondary_section',
            [
                'label' => __( 'Section 2', 'ali' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'ali_sw_secondary_label',
            [
                'label' => __( 'Title', 'ali' ),
                'type' => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $this->add_control(
            'ali_sw_secondary_content_type',
            [
                'label' => __( 'Type', 'ali' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'content',
                'options' => [
                    'image'  => __( 'Image','ali' ),
                    'content' => __( 'Text Editor','ali' ),
                    'saved_template' => __( 'Elementor Template','ali' ),
                ],
            ]
        );

        $this->add_control(
            'ali_sw_secondary_content_wysiwyg',
            [
                'label' => __( 'Text Editor','ali' ),
                'type' => \Elementor\Controls_Manager::WYSIWYG,
                'condition' => [
                    'ali_sw_secondary_content_type' => 'content'
                ]
            ]
        );

        $this->add_control(
            'ali_sw_secondary_content_image',
            [
                'label' => __( 'Choose Image', 'ali' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'ali_sw_secondary_content_type' => 'image'
                ]
            ]
        );

        $this->add_control(
            'ali_sw_secondary_content_saved_template',
            [
                'label' => __( 'Shortcode', 'ali' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => __( 'Shortcode', 'ali' ),
                'condition' => [
                    'ali_sw_secondary_content_type' => 'saved_template'
                ]
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
            'ali_sw_style_switch_button_section',
            [
                'label' => __( 'Switch Button', 'ali' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'ali_sw_style_switch_button_deactive_color',
            [
                'label' => __( 'Box Around Color 1', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Core\Schemes\Color::get_type(),
                    'value' => \Elementor\Core\Schemes\Color::COLOR_1,
                ],
                'default' => '#ccc',
                'selectors' => [
                    '{{WRAPPER}} .ali-switch-content__button-slider' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'ali_sw_style_switch_button_active_color',
            [
                'label' => __( 'Box Around Color 2', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Core\Schemes\Color::get_type(),
                    'value' => \Elementor\Core\Schemes\Color::COLOR_1,
                ],
                'default' => '#ffbd5a',
                'selectors' => [
                    '{{WRAPPER}} input:checked + .ali-switch-content__button-slider' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'ali_sw_style_switch_slider_color',
            [
                'label' => __( 'Switch Color', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Core\Schemes\Color::get_type(),
                    'value' => \Elementor\Core\Schemes\Color::COLOR_1,
                ],
                'default' => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .ali-switch-content__button-slider:before' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'ali_sw_style_switch_button_width',
            [
                'label' => __( 'Size', 'ali' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 15,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ali-switch-content__button-switch' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ali_sw_style_switch_button_spacing',
            [
                'label' => __( 'Spacing', 'ali' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 20,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ali-switch-content__button-switch' => 'margin-left: {{SIZE}}{{UNIT}}; margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ali_sw_style_switch_button_margin_bottom',
            [
                'label' => __( 'Margin Bottom', 'ali' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 20,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ali-switch-content__button' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ali_sw_style_switch_button_border_radius',
            [
                'label' => __( 'Box Around Border Radius', 'ali' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ali-switch-content__button-slider.round' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'ali_sw_style_switch_button_slider_border_radius',
            [
                'label' => __( 'Switch Border Radius', 'ali' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 50,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ali-switch-content__button-slider.round:before' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'ali_sw_label_section',
            [
                'label' => __( 'Title', 'ali' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs(
            'label_tabs'
        );

        $this->start_controls_tab(
            'label_primary_tabs',
            [
                'label' => __( 'Section 1', 'ali' ),
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'label_typography',
                'selector' => '{{WRAPPER}} .ali-switch-content-primary-label',
                'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_2,
            ]
        );

        $this->add_control(
            'ali_sw_primary_label_color',
            [
                'label' => __( 'Color', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Core\Schemes\Color::get_type(),
                    'value' => \Elementor\Core\Schemes\Color::COLOR_1,
                ],
                'default' => '#000',
                'selectors' => [
                    '{{WRAPPER}} .ali-switch-content-primary-label' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'label_secondary_tabs',
            [
                'label' => __( 'Section 2', 'ali' ),
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'label_secondary_typography',
                'selector' => '{{WRAPPER}} .ali-switch-content-secondary-label',
                'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_2,
            ]
        );

        $this->add_control(
            'ali_sw_secondary_label_color',
            [
                'label' => __( 'Color', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Core\Schemes\Color::get_type(),
                    'value' => \Elementor\Core\Schemes\Color::COLOR_1,
                ],
                'default' => '#000',
                'selectors' => [
                    '{{WRAPPER}} .ali-switch-content-secondary-label' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        $this->start_controls_section(
            'ali_sw_section',
            [
                'label' => __( 'Content', 'ali' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs(
            'content_tabs'
        );

        $this->start_controls_tab(
            'content_primary_tabs',
            [
                'label' => __( 'Section 1', 'ali' ),
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'selector' => '{{WRAPPER}} .ali-sw-primary-content-wysiwyg',
                'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_3,
            ]
        );

        $this->add_control(
            'ali_sw_primary_content_color',
            [
                'label' => __( 'Color', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Core\Schemes\Color::get_type(),
                    'value' => \Elementor\Core\Schemes\Color::COLOR_1,
                ],
                'default' => '#000',
                'selectors' => [
                    '{{WRAPPER}} .ali-sw-primary-content-wysiwyg' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'content_secondary_tabs',
            [
                'label' => __( 'Section 2', 'ali' ),
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'content_secondary_typography',
                'selector' => '{{WRAPPER}} .ali-sw-secondary-content-wysiwyg',
                'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_3,
            ]
        );

        $this->add_control(
            'ali_sw_secondary_content_color',
            [
                'label' => __( 'Color', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Core\Schemes\Color::get_type(),
                    'value' => \Elementor\Core\Schemes\Color::COLOR_1,
                ],
                'default' => '#000',
                'selectors' => [
                    '{{WRAPPER}} .ali-sw-secondary-content-wysiwyg' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->end_controls_section();
    }
    protected function render() {

        $settings = $this->get_settings_for_display();
        ?>
        <div class="ali-switch-content" data-ali-switch-content>
            <div class="ali-switch-content__button" data-ali-switch-content-button>
                <?php
                if (!empty($settings['ali_sw_primary_label'])) {
                    ?>
                    <div class="ali-switch-content-primary-label" data-ali-switch-content-primary-label>
                        <?php echo $settings['ali_sw_primary_label']; ?>
                    </div>
                    <?php
                }
                ?>
                <label class="ali-switch-content__button-switch" data-ali-switch-content-button-switch>
                    <input type="checkbox" class="ali-switch-content__button-checkbox" data-ali-switch-content-button-checkbox></input>
                    <span class="ali-switch-content__button-slider round"></span>
                </label>
                <?php
                if (!empty($settings['ali_sw_secondary_label'])) {
                    ?>
                    <div class="ali-switch-content-secondary-label" data-ali-switch-content-secondary-label>
                        <?php echo $settings['ali_sw_secondary_label']; ?>
                    </div>
                    <?php
                }
                ?>
            </div>
            <div class="ali-switch-content__inner" data-ali-switch-content>
                <div class="ali-switch-content-primary" data-ali-switch-content-primary>
                    <?php
                    if (!empty($settings['ali_sw_primary_content_wysiwyg']) && $settings['ali_sw_primary_content_type' ] == 'content' ) {
                        ?>
                        <div class="ali-sw-primary-content-wysiwyg" data-ali-switch-content-primary-content-wysiwyg>
                            <?php echo $settings['ali_sw_primary_content_wysiwyg']; ?>
                        </div>
                        <?php
                    }
                    ?>

                    <?php
                    if (!empty($settings['ali_sw_primary_content_saved_template']) && $settings['ali_sw_primary_content_type' ] == 'saved_template' ) {
                        ?>
                        <div class="ali-sw-primary-content__saved-template" data-ali-switch-content-primary-content-saved-template>
                            <?php echo do_shortcode($settings["ali_sw_primary_content_saved_template"]); ?>
                        </div>
                        <?php
                    }
                    ?>

                    <?php
                    if (!empty($settings['ali_sw_primary_content_image'] ) && $settings['ali_sw_primary_content_type' ] == 'image') {
                        if ( !empty($settings['ali_sw_primary_content_image']['url'] ) ) {
                            ?>
                            <img class="ali-switch-content-primary-content-image"  src="<?php echo $settings['ali_sw_primary_content_image']['url']; ?>" alt="" data-ali-switch-content-primary-image>
                            <?php
                        }
                    }
                    ?>
                </div>
                <!-- Content Secondary  -->
                <div class="ali-switch-content-secondary" data-ali-switch-content-secondary>
                    <?php
                    if (!empty($settings['ali_sw_secondary_content_wysiwyg']) && $settings['ali_sw_secondary_content_type' ] == 'content' ) {
                        ?>
                        <div class="ali-sw-secondary-content-wysiwyg">
                            <?php echo $settings['ali_sw_secondary_content_wysiwyg']; ?>
                        </div>
                        <?php
                    }
                    ?>

                    <?php
                    if (!empty($settings['ali_sw_secondary_content_saved_template']) && $settings['ali_sw_secondary_content_type' ] == 'saved_template' ) {
                        ?>
                        <div class="ali-sw-secondary-content__saved-template">
                            <?php echo do_shortcode($settings["ali_sw_secondary_content_saved_template"]); ?>
                        </div>
                        <?php
                    }
                    ?>

                    <?php
                    if (!empty($settings['ali_sw_secondary_content_image'] ) && $settings['ali_sw_secondary_content_type' ] == 'image') {
                        if ( !empty($settings['ali_sw_secondary_content_image']['url'] ) ) {
                            ?>
                            <img class="ali-switch-content-secondary-content-image" src="<?php echo $settings['ali_sw_secondary_content_image']['url']; ?>" alt="" >
                            <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php
    }
}
