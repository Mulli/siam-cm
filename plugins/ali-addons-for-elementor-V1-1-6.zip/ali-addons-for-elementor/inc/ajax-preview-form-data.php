<?php
//require_once (__DIR__ . '/helped.php');
add_action('wp_ajax_ali_preview_form_data', 'ali_preview_form_data');
add_action('wp_ajax_nopriv_ali_preview_form_data', 'ali_preview_form_data');

function ali_preview_form_data()
{
    if (!empty($_POST['fields'])) {
        $fields = stripslashes($_POST['fields']);
        $fields = json_decode($fields, true);
        $fields = array_unique($fields, SORT_REGULAR);

        $fields_new = array();
        foreach ($fields as $field) {
            if (!empty($field['value'])) {
                $fields_new[] = $field;
            }
        }
        $fields = $fields_new;
        //print_r($fields);
        ?>
        <div class="ali-preview-title"> <?php echo $_POST['title']; ?></div>
        <?php
        foreach ($fields as $field) {
            if (is_array($field['value'])) {
                $field['value'] = implode(", ", $field['value']);
            }
            ?>
            <div class="ali-preview__item">
                <span class="ali-preview__item-label"><?php echo $field['label']; ?> :</span> <span class="ali-preview__item-value"><?php echo $field['value']; ?></span>
            </div>
            <?php
        }
    }
    wp_die();
}

