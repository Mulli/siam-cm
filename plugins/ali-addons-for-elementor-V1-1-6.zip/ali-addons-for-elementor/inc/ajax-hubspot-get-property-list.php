<?php
require_once (__DIR__ . '/helped.php');
add_action( 'wp_ajax_ali_hubspot_contact_property_list', 'ali_hubspot_contact_property_list' );
add_action( 'wp_ajax_nopriv_ali_hubspot_contact_property_list', 'ali_hubspot_contact_property_list' );

function ali_hubspot_contact_property_list(){
    $hubspot_access_token = get_option('ali-hubspot-access-token');
    $group_name = $_REQUEST['group'];
    $url = 'https://api.hubapi.com/properties/v1/contacts/groups/named/'.$group_name.'?&includeProperties=true';
    if (!empty($group_name)) {
        $response = Helped::getStr($url, $hubspot_access_token);
        $result = $response->properties;
        foreach ($result as $item) {
            echo '<div class="ali-hubspot-list__group" style="padding-top:5px;">
                    <label><strong>' . $item->label . '</strong></label>
                    <div class="ali-hubspot-list__group-value" style="padding-bottom:3px;">
                        <input type="text" value="' . $item->name . '" readonly>
                    </div>
                </div>';
        }
    }
    wp_die();
}