<div class="ali-wrap">
    <form method="post" action="options.php" data-ali-features>
        <?php settings_fields('ali-addons-features-settings-group'); ?>
        <?php do_settings_sections('ali-addons-features-settings-group'); ?>
        <div class="ali-toggle-features">
            <br>
            <br>
            <div class="ali-toggle-features__button" data-ali-toggle-features-enable>Enable All</div>
            <div class="ali-toggle-features__button ali-toggle-features__button--disable"
                 data-ali-toggle-features-disable>Disable All
            </div>
            <div class="ali-toggle-features__button" data-ali-features-save><?php _e('Save Settings', 'ali'); ?></div>
            <br>
        </div>

        <ul class="ali-features">
            <?php
            require_once(__DIR__ . '/feature.php');
            $features = json_decode(ALI_FEATURES, true);
            $license_check = get_option('ali_license_status');
            foreach ($features as $feature) :
                $feature_off = '';
                $feature_on = esc_attr(get_option($feature['option'], 2));
                if ($license_check !== 'valid') {
                    $feature_off = '1';
                }
                if ($feature_on == 2) {
                    $feature_on = 1;
                }
                ?>
                <li class="ali-features__item">
                    <label class="ali-switch">
                        <input type="checkbox"<?php if (empty($feature_off)) : ?> name="<?php echo $feature['option']; ?>"<?php endif; ?>
                               value="1" <?php if ($license_check == 'valid') { checked( $feature_on, 1 ); } ?><?php if (!empty($feature_off)) { echo ' disabled'; } ?>>
                        <span class="ali-slider round"></span>
                    </label>
                    <?php echo $feature['name']; ?>
                </li>
            <?php endforeach; ?>
        </ul>
    </form>