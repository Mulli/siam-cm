<?php
add_action( 'wp_ajax_ali_getresponse_select_list', 'ali_getresponse_select_list' );
add_action( 'wp_ajax_nopriv_ali_getresponse_select_list', 'ali_getresponse_select_list' );

function ali_getresponse_select_list(){

    $api = get_option('ali-get-response-api-key');
    $get_response_url_campaigns = "https://api.getresponse.com/v3/campaigns/";
    $gs_data = array(
        'headers'     => array(
            'Content-Type' => 'application/json',
            'X-Auth-Token' => 'api-key '.$api,
        ),
    );

    $response = wp_remote_get($get_response_url_campaigns, $gs_data);
    $result = json_decode(wp_remote_retrieve_body( $response ));

    foreach($result as $item){
        echo '<div class="ali-getresponse-list__inner"><label class="elementor-control-title">'.$item->name.'</label><div class="ali-getresponse-list__inner-item"><input type="text" value="'.$item->campaignId.'" reaonly/></div></div>';
    }
    wp_die();
}