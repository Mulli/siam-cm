<?php
add_action( 'wp_ajax_ali_get_country_code', 'ali_get_country_code' );
add_action( 'wp_ajax_nopriv_ali_get_country_code', 'ali_get_country_code' );

function ali_get_country_code(): void
{
    $ipaddress='';
    if( array_key_exists('HTTP_X_FORWARDED_FOR', $_SERVER) && !empty($_SERVER['HTTP_X_FORWARDED_FOR']) ) {
        if (strpos($_SERVER['HTTP_X_FORWARDED_FOR'], ',')>0) {
            $addr = explode(",",$_SERVER['HTTP_X_FORWARDED_FOR']);
            $ipaddress= trim($addr[0]);
        } else {
            $ipaddress= $_SERVER['HTTP_X_FORWARDED_FOR'];
        }
    }
    else {
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    }

    $url = 'http://ip-api.com/php/'.$ipaddress;
    $query = wp_remote_get($url, ['timeout' => 5]);
    if ( is_wp_error( $query ) ) {
        echo 'error'.$ipaddress;
    } else {
        $response =  @unserialize(wp_remote_retrieve_body( $query ));
        if($response && $response['status'] == 'success') {
            echo $response['countryCode'];
        } else {
            echo 'error';
        }
    }

    wp_die();
}