<?php
define('ALI_FEATURES', json_encode(array(
            array(
                'name' => 'Custom Search Result',
                'option' => 'ali-custom-search-results',
            ),
            array(
                'name' => 'Tooltip',
                'option' => 'ali-tooltip',
            ),
            array(
                'name' => 'Image Select Field',
                'option' => 'ali-image-select-field',
            ),
            array(
                'name' => 'Term Field',
                'option' => 'ali-term-field',
            ),
            array(
                'name' => 'Mask For Elementor Form',
                'option' => 'ali-mask-for-elementor-form',
            ),
            array(
                'name' => 'Min - Max Length',
                'option' => 'ali-min-max-length',
            ),
            array(
                'name' => 'Range Slider',
                'option' => 'ali-range-slider',
            ),
            array(
                'name' => 'Form Style',
                'option' => 'ali-style-for-elementor-form',
            ),
            array(
                'name' => 'Select Autocomplete Field',
                'option' => 'ali-select-autocomplete',
            ),
            array(
                'name' => 'Select2 Field',
                'option' => 'ali-select2-field',
            ),
            array(
                'name' => 'International Field',
                'option' => 'ali-international-tel-field',
            ),
            array(
                'name' => 'Google Sheet Integration',
                'option' => 'ali-google-sheet-integration',
            ),

            array(
                'name' => 'Google Calendar Integration',
                'option' => 'ali-google-calendar-integration',
            ),

            array(
                'name' => 'Hubspot Integration',
                'option' => 'ali-hubspot-integration',
            ),

            array(
                'name' => 'Brevo Integration',
                'option' => 'ali-brevo-integration',
            ),

            array(
                'name' => 'Sendy Integration',
                'option' => 'ali-sendy-integration',
            ),

            array(
                'name' => 'Get Response Integration',
                'option' => 'ali-get-response-integration',
            ),

            array(
                'name' => 'Signature Field',
                'option' => 'ali-signature-field',
            ),

            array(
                'name' => 'Add ID For Email',
                'option' => 'ali-add-id-for-email-submission',
            ),

            array(
                'name' => 'Switch Content',
                'option' => 'ali-sw',
            ),

            array(
                'name' => 'Ali Calculation',
                'option' => 'ali-calculation',
            ),

            array(
                'name' => 'Conditional',
                'option' => 'ali-conditional',
            ),

            array(
                'name' => 'Preview Form Data',
                'option' => 'ali-preview-form-data',
            ),

            array(
                'name' => 'Register User',
                'option' => 'ali-register-user',
            ),

            array(
                'name' => 'Icon For Field',
                'option' => 'ali-icon-for-field',
            ),
        )
    )
);
