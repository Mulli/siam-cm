<?php
require_once(__DIR__ . '/helped.php');
add_action('wp_ajax_ali_brevo_get_attr', 'ali_brevo_get_attr');
add_action('wp_ajax_nopriv_ali_brevo_get_attr', 'ali_brevo_get_attr');

function ali_brevo_get_attr()
{
    $api = get_option('ali-brevo-api-key');
    $url = 'https://api.brevo.com/v3/contacts/attributes';
    if (!empty($api)) {
        $response = Helped::brevo_get_data($api,$url);
        $array = json_decode($response);
        $attributes =$array->attributes;
        ?>
        <h3 class="ali-brevo-title" style="margin-bottom: 5px;">Attributes:</h3>
        <div class="ali-brevo-item" style="margin-bottom: 5px;"><input type="text" value="email (require)" readonly></div>
        <?php foreach ($attributes as $key => $val) : ?>
            <div class="ali-brevo-item" style="margin-bottom: 5px;"><input type="text" value=" <?php echo $val->name; ?>" eadonly></div>
        <?php endforeach;
    }
    wp_die();
}
