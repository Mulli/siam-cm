<div class="ali-integration__item" >
    <form method="post" action="options.php">
        <?php settings_fields( 'ali-hubspot-group' ); ?>
        <?php do_settings_sections( 'ali-hubspot-group' ); ?>
        <?php $hubspot_access_token = esc_attr( get_option( 'ali-hubspot-access-token' ) ); ?>
        <div style="padding-top: 30px;">
            <h3>HubSpot</h3>
            <b><a href="https://app.hubspot.com/login" target="_blank"><?php esc_html_e( 'Take Access Token', 'ali' ); ?></a></b>
        </div>
        <table class="form-table">
            <tr valign="top">
                <th scope="row"><?php _e('Private App Access Token','ali'); ?></th>
                <td><input type="text" name="ali-hubspot-access-token" value="<?php echo $hubspot_access_token; ?>" class="regular-text"/></td>
            </tr>
        </table>
        <?php submit_button(__('Save Settings','ali')); ?>
    </form>
</div>

<div class="ali-integration__item" >
    <form method="post" action="options.php">
        <?php settings_fields( 'ali-get-response-group' ); ?>
        <?php do_settings_sections( 'ali-get-response-group' ); ?>
        <?php $get_response_api = esc_attr( get_option( 'ali-get-response-api-key' ) ); ?>
        <div style="padding-top: 30px;">
            <h3>Get Response</h3>
            <b><a href="https://www.getresponse.com/" target="_blank"><?php esc_html_e( 'Take API Key', 'ali' ); ?></a></b>
        </div>
        <table class="form-table">
            <tr valign="top">
                <th scope="row"><?php _e('API Key','ali'); ?></th>
                <td><input type="text" name="ali-get-response-api-key" value="<?php echo $get_response_api; ?>" class="regular-text"/></td>
            </tr>
        </table>
        <?php submit_button(__('Save Settings','ali')); ?>
    </form>
</div>

<div class="ali-integration__item" >
    <form method="post" action="options.php">
        <?php settings_fields( 'ali-brevo-group' ); ?>
        <?php do_settings_sections( 'ali-brevo-group' ); ?>
        <?php $brevo_api_key = esc_attr( get_option( 'ali-brevo-api-key' ) ); ?>
        <div style="padding-top: 30px;">
            <h3>Brevo</h3>
            <b><a href="https://app.brevo.com/settings/keys/api" target="_blank"><?php esc_html_e( 'Take API Key', 'ali' ); ?></a></b>
        </div>
        <table class="form-table">
            <tr valign="top">
                <th scope="row"><?php _e('Brevo API Key','ali'); ?></th>
                <td><input type="text" name="ali-brevo-api-key" value="<?php echo $brevo_api_key; ?>" class="regular-text"/></td>
            </tr>
        </table>
        <?php submit_button(__('Save Settings','ali')); ?>
    </form>
</div>

<div class="ali-integration__item" >
    <form method="post" action="options.php">
        <?php settings_fields( 'ali-gs-group' ); ?>
        <?php do_settings_sections( 'ali-gs-group' ); ?>
        <?php

        $client_id     = esc_attr( get_option( 'ali-gs-client-id' ) );
        $client_secret = esc_attr( get_option( 'ali-gs-client-secret' ) );
        $redirect =  get_admin_url(null,'admin.php?page=ali&connect_type=google_sheets');
        //$redirect      = "http://localhost/ali/wp-admin/admin.php?page=ali-integrations&connect_type=google_sheets";

        if ( ! empty( $_GET['connect_type'] ) && $_GET['connect_type'] == 'google_sheets' && ! empty( $_GET['code'] ) ) {
            // Authorization
            $code = $_GET['code'];
            // Token
            $url  = 'https://accounts.google.com/o/oauth2/token';
            $data = "code=$code&client_id=$client_id&client_secret=$client_secret&redirect_uri=" . urlencode($redirect) . "&grant_type=authorization_code";

            $gg_sheet_data = array(
                'headers'     => array(
                    "Content-Type: application/x-www-form-urlencoded"
                ),
                'body' => $data
            );

            $query = wp_remote_post($url, $gg_sheet_data);
            $response =  wp_remote_retrieve_body( $query );
            $array = json_decode( $response );
            if ( ! empty( $array->access_token ) && ! empty( $array->refresh_token ) && ! empty( $array->expires_in ) ) {

                $ali_ggsheets_expired_at = time() + $array->expires_in;
                update_option( 'ali-gs-expires', $array->expires_in );
                update_option( 'ali-gs-expired-token', $ali_ggsheets_expired_at );
                update_option( 'ali-gs-access-token', $array->access_token );
                update_option( 'ali-gs-refresh-token', $array->refresh_token );
            }
        }
        ?>
        <div style="padding-top: 30px;">
            <h3>Google Sheet</h3>
            <b><a href="https://console.developers.google.com" target="_blank"><?php _e('https://console.developers.google.com/','ali'); ?></a></b>
        </div>
        <table class="form-table">
            <tr valign="top">
                <th scope="row"><?php _e('Client ID','ali'); ?></th>
                <td><input type="text" name="ali-gs-client-id" value="<?php echo $client_id; ?>" class="regular-text"/></td>
            </tr>
            <tr valign="top">
                <th scope="row"><?php _e('Client Secret','ali'); ?></th>
                <td class="ali-settings-page-td">
                    <input type="text" name="ali-gs-client-secret" value="<?php echo $client_secret; ?>" class="regular-text"/>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row"><?php _e('Redirect URL','ali'); ?></th>
                <td><input type="text" readonly="readonly" value="<?php echo $redirect; ?>" class="regular-text"/></td>
            </tr>
            <tr valign="top">
                <th scope="row"><?php _e('Generate Access Token','ali'); ?></th>
                <td>
                    <?php if ( !empty($client_id) && !empty($client_secret) ) : ?>
                        <a class="ali-toggle-features__button" href="https://accounts.google.com/o/oauth2/auth?redirect_uri=<?php echo urlencode($redirect); ?>&client_id=<?php echo $client_id; ?>&response_type=code&scope=https://www.googleapis.com/auth/spreadsheets&approval_prompt=force&access_type=offline">Authorize</a>
                    <?php else : ?>
                        <?php _e('Get Client ID and Client Secret before Authorize','ali'); ?>
                    <?php endif; ?>
                </td>
            </tr>
        </table>
        <?php submit_button(__('Save Settings','ali')); ?>
    </form>
</div>

<div class="ali-integration__item" >
        <form method="post" action="options.php">
            <?php settings_fields( 'ali-google-calendar-group' ); ?>
            <?php do_settings_sections( 'ali-google-calendar-group' ); ?>
            <?php
            $redirect      =  get_admin_url(null,'admin.php?page=ali-integrations&connect_type=google_calendar');
            //$redirect      = "http://localhost/ali/wp-admin/admin.php?page=ali-integrations&connect_type=google_calendar";
            $gg_cld_client_id     = esc_attr( get_option( 'ali-google-calendar-client-id' ) );
            $gg_cld_client_secret = esc_attr( get_option( 'ali-google-calendar-client-secret' ) );
            $client_api_key = esc_attr( get_option( 'ali-google-calendar-client-api-key' ) );

            if ( ! empty( $_GET['connect_type'] ) && $_GET['connect_type'] == 'google_calendar' && ! empty( $_GET['code'] ) ) {
                // Authorization
                $code = $_GET['code'];
                $url  = 'https://accounts.google.com/o/oauth2/token';
                
                // Token
                $curl = curl_init();
                $data = "code=$code&client_id=$gg_cld_client_id&client_secret=$gg_cld_client_secret&redirect_uri=" . urlencode($redirect) . "&grant_type=authorization_code";
                $gg_calendar_data = array(
                    'headers'     => array(
                        "Content-Type: application/x-www-form-urlencoded"
                    ),
                    'body' => $data
                );
                $query = wp_remote_post($url, $gg_calendar_data);
                $response =  wp_remote_retrieve_body( $query );
                
                //echo $response;
                $array = json_decode( $response );
                if ( ! empty( $array->access_token ) && ! empty( $array->refresh_token ) && ! empty( $array->expires_in ) ) {
                    $ali_gg_calendar_expired_at = time() + $array->expires_in;
                    update_option( 'ali-google-calendar-expires', $array->expires_in );
                    update_option( 'ali-google-calendar-expired-token', $ali_gg_calendar_expired_at );
                    update_option( 'ali-google-calendar-access-token', $array->access_token );
                    update_option( 'ali-google-calendar-refresh-token', $array->refresh_token );

                    $google_calendar = array(
                        'headers'     => array(
                            'Authorization'=>'Bearer '.$array->access_token,
                            'Content-Type'=> 'application/json'
                        ),
                    );
                    $query2 = wp_remote_get("https://www.googleapis.com/calendar/v3/users/me/calendarList?key=$client_api_key", $google_calendar);
                    $response2 =  wp_remote_retrieve_body( $query2 );
                    $response2 = json_decode($response2);
                    update_option('ali-gg-cld-list',$response2);

                }
            }
            ?>
            <div style="padding-top: 30px;">
                <h3>Google Calendar</h3>
                <b><a href="https://console.developers.google.com" target="_blank"><?php _e('https://console.developers.google.com/','ali'); ?></a></b>
            </div>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><?php esc_html_e( 'Client ID', 'ali' ); ?></th>
                    <td><input type="text" name="ali-google-calendar-client-id" value="<?php echo $gg_cld_client_id; ?>" class="regular-text"/></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e( 'Client Secret', 'ali' ); ?></th>
                    <td class="ali-settings-page-td">
                        <input type="text" name="ali-google-calendar-client-secret" value="<?php echo $gg_cld_client_secret; ?>" class="regular-text"/>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e( 'API Key', 'ali' ); ?></th>
                    <td class="ali-settings-page-td">
                        <input type="text" name="ali-google-calendar-client-api-key" value="<?php echo $client_api_key; ?>" class="regular-text"/>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e( 'Authorized redirect URI', 'ali' ); ?></th>
                    <td><input type="text" readonly="readonly" value="<?php echo $redirect; ?>" class="regular-text"/></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e( 'Authorize', 'ali' ); ?></th>
                    <td>
                        <?php if ( ! empty( $gg_cld_client_id ) && ! empty( $gg_cld_client_secret ) ) : ?>
                            <a class="ali-toggle-features__button" href="https://accounts.google.com/o/oauth2/auth?redirect_uri=<?php echo urlencode($redirect); ?>&client_id=<?php echo $gg_cld_client_id; ?>&response_type=code&scope=https://www.googleapis.com/auth/calendar.readonly https://www.googleapis.com/auth/calendar.events&approval_prompt=force&access_type=offline">Authorize</a>
                        <?php else : ?>
                            <?php esc_html_e( 'To setup Gmail integration properly you should save Client ID and Client Secret.', 'ali' ); ?>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>
            <?php submit_button( __( 'Save Settings', 'ali' ) ); ?>
        </form>
    </div>

