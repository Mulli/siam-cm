<?php
require_once (__DIR__ . '/helped.php');
add_action( 'wp_ajax_ali_hubspot_group_list', 'ali_hubspot_group_list' );
add_action( 'wp_ajax_nopriv_ali_hubspot_group_list', 'ali_hubspot_group_list' );

function ali_hubspot_group_list(){
    $hubspot_access_token = get_option('ali-hubspot-access-token');

    if (!empty($hubspot_access_token)) {
        $url = 'https://api.hubapi.com/properties/v1/contacts/groups';
        $response = Helped::getStr($url, $hubspot_access_token);
        foreach ($response as $item) {
            echo '<div class="ali-hubspot-list__item" style="padding-top:5px;">
                    <label><strong>' . $item->displayName . '</strong></label>
                    <div class="ali-hubspot-list__item-value" style="padding-bottom:3px;">
                        <input type="text" value="' . $item->name . '" readonly>
                    </div>
                </div>';
        }
    }
    wp_die();
}

