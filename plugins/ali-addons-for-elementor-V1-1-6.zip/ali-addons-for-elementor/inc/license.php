<?php
const ALI_URL = 'https://aliaddons.com';
const ALI_PRODUCT_ID = 117;
class Ali_License
{
    public function __construct()
    {
        add_action('admin_menu', [$this, 'ali_license_menu']);
        add_action('admin_init', [$this, 'ali_activate_license']);
        add_action('admin_init', [$this, 'ali_deactivate_license']);
        add_action('admin_init', [$this, 'ali_check_license']);
        add_action('admin_init', [$this, 'ali_register_option']);
    }

    public function ali_license_menu()
    {
        add_submenu_page('ali-addons-for-elementor', 'License', 'License', 'edit_others_posts', 'ali-license', [$this, 'ali_license_page']);
    }

    public function ali_license_page()
    {
        $license = get_option('ali_license_key');
        $status = get_option('ali_license_status');
        ?>
        <div class="wrap">
        <h2><?php _e('License Settings'); ?></h2>
        <form method="post" action="options.php">
            <?php settings_fields('ali_license'); ?>
            <table class="form-table">
                <tbody>
                <tr valign="top">
                    <th scope="row" valign="top">
                        <?php _e('License Key'); ?>
                    </th>
                    <td>
                        <input placeholder="Enter your license key" style="max-width: 500px" name="ali_license_key" type="password" class="regular-text ali_license_key" value="<?php esc_attr_e($license); ?>"/>
                        <?php
                        if ($license == '') {
                            echo '<p class="description">' . sprintf(esc_html__('You can find your license key in your %saccount%s.', 'ali'), '<a href="https://aliaddons.com/my-account/" target="_blank">', '</a>') . '</p>';
                        }
                        ?>

                        <?php
                        if ($license != '' && $status == '') {
                            wp_nonce_field('ali_nonce', 'ali_nonce'); ?>
                            <input type="submit" class="button-secondary ali_license_activate"
                                   name="ali_license_activate" value="<?php _e('Activate License'); ?>"/>
                        <?php } else { ?>
                            <?php if ($status == 'valid') { ?>
                                <?php wp_nonce_field('ali_nonce', 'ali_nonce'); ?>
                                <input type="submit" class="button-secondary" name="ali_license_deactivate" value="<?php _e('Deactivate License'); ?>"/>
                                <div class="ali-license_status">Status: <strong style="color:green;"><?php echo $status; ?></strong></div>

                            <?php } else if ($license != '' && $status != '') {
                                wp_nonce_field('ali_nonce', 'ali_nonce'); ?>
                                <input type="submit" class="button-secondary ali_license_activate"
                                       name="ali_license_activate" value="<?php _e('Activate License'); ?>"/>
                                <div class="ali-license_status">Status: <strong
                                            style="color:red;"><?php echo $status; ?></strong></div>

                            <?php }
                        } ?>
                    </td>
                </tr>

                </tbody>
            </table>
            <?php submit_button(); ?>
        </form>
        <?php
    }

    public function ali_register_option()
    {
        register_setting('ali_license', 'ali_license_key', 'ali_sanitize_license');
    }


    public function ali_sanitize_license($new)
    {
        $old = get_option('ali_license_key');
        if ($old && $old != $new) {
            delete_option('ali_license_status');
        }
        return $new;
    }

    public function ali_deactivate_license()
    {
        if (isset($_POST['ali_license_deactivate'])) {
            $license = trim(get_option('ali_license_key'));

            // data to send in our API request
            $api_params = array(
                'edd_action' => 'deactivate_license',
                'license' => $license,
                'item_id' => ALI_PRODUCT_ID,
                'url' => home_url(),
                'environment' => function_exists('wp_get_environment_type') ? wp_get_environment_type() : 'production',
            );
            $response = wp_remote_post(ALI_URL, array('body' => $api_params, 'timeout' => 15, 'sslverify' => false));
            if (is_wp_error($response)) {
                return false;
            }
            $license_data = json_decode(wp_remote_retrieve_body($response));
            if ($license_data->license == 'deactivated') {
                delete_option('ali_license_status');
                delete_option('ali_license_key');
            }elseif($license_data->license == 'failed'){
                delete_option('ali_license_status');
                delete_option('ali_license_key');
            }
            wp_redirect(admin_url('admin.php?page=ali-license'));
            exit();
        }
    }

    public function ali_activate_license()
    {

        if (isset($_POST['ali_license_activate'])) {

            if (!check_admin_referer('ali_nonce', 'ali_nonce')) {
                return;
            }
            $license = trim(get_option('ali_license_key'));

            $api_params = array(
                'edd_action' => 'activate_license',
                'license' => $license,
                'item_id' => ALI_PRODUCT_ID,
                'url' => home_url()
            );

            $response = wp_remote_post(ALI_URL, array('timeout' => 15, 'body' => $api_params));

            if (is_wp_error($response) || 200 !== wp_remote_retrieve_response_code($response)) {

                $message = (is_wp_error($response) && !empty($response->get_error_message())) ? $response->get_error_message() : __('An error occurred, please try again.');

            } else {

                $license_data = json_decode(wp_remote_retrieve_body($response));

                if (false === $license_data->success) {

                    switch ($license_data->error) {

                        case 'expired' :

                            $message = sprintf(
                                __('Your license key expired on %s.'),
                                date_i18n(get_option('date_format'), strtotime($license_data->expires, current_time('timestamp')))
                            );
                            break;

                        case 'revoked' :

                            $message = __('Your license key has been disabled.');
                            break;

                        case 'missing' :

                            $message = __('Invalid license.');
                            break;

                        case 'invalid' :
                        case 'site_inactive' :

                            $message = __('Your license is not active for this URL.');
                            break;

                        case 'item_name_mismatch' :

                            $message = sprintf(__('This appears to be an invalid license key for %s.'), "Ali Addons For Elementor");
                            break;

                        case 'no_activations_left':

                            $message = __('Your license key has reached its activation limit.');
                            break;

                        default :

                            $message = __('An error occurred, please try again.');
                            break;
                    }

                }

            }

            if (!empty($message)) {
                $base_url = admin_url('admin.php?page=ali-license');
                $redirect = add_query_arg(array('sl_activation' => 'false', 'message' => urlencode($message)), $base_url);
                update_option('ali_license_status', $message);

                wp_redirect($redirect);
                exit();
            }

            update_option('ali_license_status', $license_data->license);
            wp_redirect(admin_url('admin.php?page=ali-license'));
            exit();
        }
    }

    public function ali_check_license()
    {

        $license = trim(get_option('ali_license_key'));
        $status = get_option('ali_license_status');

        if ($status !== '') {
            return;
        }
        $api_params = array(
            'edd_action' => 'check_license',
            'license' => $license,
            'item_id' => ALI_PRODUCT_ID,
            'url' => home_url(),
            'environment' => function_exists('wp_get_environment_type') ? wp_get_environment_type() : 'production',
        );
        $response = wp_remote_post(ALI_URL, array('body' => $api_params, 'timeout' => 15, 'sslverify' => false));
        if (is_wp_error($response)) {
            return false;
        }

        $license_data = json_decode(wp_remote_retrieve_body($response));
        update_option('ali_license_status', $license_data->license);
    }

}