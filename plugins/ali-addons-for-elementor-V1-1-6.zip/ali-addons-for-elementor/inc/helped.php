<?php
class Helped {
    static function getStr(string $url, $hubspot_access_token){
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                'Authorization: Bearer ' . $hubspot_access_token
            ),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        return json_decode($response);
    }

    static function brevo_get_data($api_key,$url){
        $brevo_data = array(
            'headers'     => array(
                'Accept'=>'application/json ',
                'api-key'=> $api_key
            ),
        );

        $response = wp_remote_get($url, $brevo_data);
        return wp_remote_retrieve_body( $response );

    }

}
