<?php
add_action( 'wp_ajax_ali_custom_search_results', 'ali_custom_search_results' );
add_action( 'wp_ajax_nopriv_ali_custom_search_results', 'ali_custom_search_results' );
function ali_custom_search_results() {
    global $wpdb;
    if ( !empty($_POST['search']) ) {
        $search = esc_sql( $_POST['search'] );
        $post_type = esc_sql( $_POST['post_type'] );

        $args = array(
            's' => $search,
        );

        if (!empty($post_type)) {
            $args['post_type'] = $post_type;
        }

        $query = new WP_Query($args);

        if ($query->have_posts()) : while($query->have_posts()) : $query->the_post();
            echo '<div class="ali-custom-search-results-item" data-ali-custom-search-href="' . get_the_permalink() . '">' . get_the_title() . '</div>';
        endwhile; endif;

        wp_reset_postdata();
    }
    wp_die();
}
?>