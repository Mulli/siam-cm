<?php
/*
 * Plugin Name: Ali Addons for Elementor
 * Description: Best Addons For Elementor with many useful extensions for Elementor Form
 * Plugin URI:  https://aliaddons.com/
 * Version:     1.1.6
 * Author:      Ali Team
 * Text Domain: ali-addons-for-elementor
 * Elementor tested up to: 3.20.0
 * Elementor Pro tested up to: 3.20.0
 */



if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}
const ALI_ADDONS_FOR_ELEMENTOR_VERSION = '1.1.6';
const ALI_ADDONS_STORE_URL = 'https://aliaddons.com';
const ALI_ADDONS_ITEM_ID = 117;

define( 'ALI_ADDONS_FOR_ELEMENTOR', plugin_basename( __FILE__ ) );

final class Ali_Addons_For_Elementor {
    const TAB_ALI = 'tab_ali';
    private static $_instance = null;

    public static function instance() {

        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;

    }
    public function __construct() {
        add_action( 'init', [ $this, 'i18n' ] );
        require_once( __DIR__ . '/extensions/custom-select-control/custom-control.php' );

        add_action( 'plugins_loaded', [ $this, 'init' ] );
        add_filter( 'elementor/init', [ $this, 'add_ali_tab'], 10,1);
        add_filter( 'elementor/controls/get_available_tabs_controls', [ $this, 'add_ali_tab'], 10,1);
        add_action( 'elementor/elements/categories_registered', [ $this, 'add_elementor_widget_categories' ] );
        add_action( 'admin_menu', array($this, 'admin_menu'));
        add_action( 'init', [ $this, 'ali_updater' ] );
        require_once( __DIR__ . '/inc/ajax-custom-search-results.php' );
        require_once( __DIR__ . '/inc/ajax-preview-form-data.php' );
        require_once( __DIR__ . '/inc/ajax-international-tel-field.php' );
        require_once( __DIR__ . '/inc/ajax-hubspot-get-group.php' );
        require_once( __DIR__ . '/inc/ajax-hubspot-get-property-list.php' );
        require_once( __DIR__ . '/inc/ajax-brevo-get-attr.php' );
        require_once( __DIR__ . '/inc/ajax-get-response-get-fields.php' );
        require_once( __DIR__ . '/inc/ajax-get-response-list.php' );
        require_once(__DIR__ . '/inc/license.php');
        new Ali_License();
    }

    public function init() {
        if ( ! did_action( 'elementor/loaded' ) ) {
            add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );
            return;
        }
        add_action( 'elementor/controls/register', [ $this, 'include_controls_files' ] );
        add_action( 'elementor/widgets/register', [ $this, 'init_widgets' ] );
        add_action( 'wp_enqueue_scripts',[ $this, 'elementor_widgets_dependencies' ] );
        add_action( 'elementor_pro/forms/fields/register', [ $this, 'include_custom_form_field_files' ] );
        add_action( 'elementor/editor/before_enqueue_styles', [ $this, 'ali_admin_enqueue_style' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'ali_admin_enqueue_style' ] );
        add_action( 'elementor/editor/after_enqueue_scripts', [$this, 'add_editor_ajax_scripts']);
        add_action( 'elementor_pro/forms/actions/register', [ $this, 'include_custom_action_files' ] );
        add_action( 'elementor/editor/before_enqueue_styles', [ $this, 'ali_admin_enqueue_script' ], 10, 1 );
        require_once ( __DIR__ . '/init.php' );
        $this-> ali_updater();
    }
    public function add_elementor_widget_categories( $elements_manager ) {

        $elements_manager->add_category(
            'ali-widgets',
            [
                'title' => __( 'ALI', 'ali' ),
                'icon' => 'fa fa-plug',
            ]
        );

    }

    public function i18n() {

        load_plugin_textdomain( 'ali' );

    }
    public function ali_admin_enqueue_style(): void
    {
        wp_enqueue_style( 'ali-admin-css', plugin_dir_url( __FILE__ ) . 'assets/css/minify/ali-admin.min.css', false, ALI_ADDONS_FOR_ELEMENTOR_VERSION );
        wp_enqueue_script( 'ali-admin-js', plugin_dir_url( __FILE__ ) . 'assets/js/minify/ali-admin.min.js', false, ALI_ADDONS_FOR_ELEMENTOR_VERSION );
    }
    public function ali_admin_enqueue_script()
    {
        wp_enqueue_script( 'ali-admin-js', plugin_dir_url( __FILE__ ) . 'assets/js/minify/ali-admin.min.js', false, ALI_ADDONS_FOR_ELEMENTOR_VERSION );
    }

    public function add_editor_ajax_scripts() {

        wp_enqueue_script( 'ali-admin-js', plugin_dir_url( __FILE__ ) . 'assets/js/minify/ali-admin.min.js', false, ALI_ADDONS_FOR_ELEMENTOR_VERSION );
        if ( !empty(get_option('ali-hubspot-access-token')) || !empty(get_option('ali-brevo-api-key'))) {
            wp_localize_script( 'ali-admin-js', 'ali_editor_params', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) )  );
        }
    }

    public function add_ali_tab($tabs){
        if( version_compare(ELEMENTOR_VERSION,'1.5.5') ){
            Elementor\Controls_Manager::add_tab(self::TAB_ALI, __( 'ALI', 'ali' ));
        } else {
            $tabs[self::TAB_ALI] = __( 'ALI', 'ali' );
        }
        return $tabs;
    }

    public function ali_updater() {
        require_once(__DIR__ . '/update.php');

        $doing_cron = defined( 'DOING_CRON' ) && DOING_CRON;
        if ( ! current_user_can( 'manage_options' ) && ! $doing_cron ) {
            return;
        }

        $license_key = trim( get_option( 'ali_license_key' ) );

        $edd_updater = new ALI_Updater(
            ALI_ADDONS_STORE_URL,
            __FILE__,
            array(
                'version' => ALI_ADDONS_FOR_ELEMENTOR_VERSION,
                'license' => $license_key,
                'item_id' => ALI_ADDONS_ITEM_ID,
                'author'  => 'Ali Team',
                'beta'    => false,
            )
        );
    }
    public function admin_notice_missing_main_plugin(): void
    {

        $message = sprintf(
            esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'ali' ),
            '<strong>' . esc_html__( 'Ali Addons For Elementor', 'ali' ) . '</strong>',
            '<strong>' . esc_html__( 'Elementor', 'ali' ) . '</strong>'
        );

        printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

    }

    public function settings_page() {
        require_once(__DIR__ . '/inc/settings.php');
    }

    public function integrations_page() {
        require_once( __DIR__ . '/inc/integrations.php' );
    }

    public function admin_menu() {
        add_menu_page('Settings', 'Ali Addons', 'manage_options', 'ali-addons-for-elementor', [$this, 'settings_page'], 'dashicons-ali-icon');
        add_submenu_page('ali-addons-for-elementor', 'Integrations', 'Integrations', 'edit_others_posts', 'ali-integrations', [$this, 'integrations_page']);
        add_action( 'admin_init',  [ $this, 'ali_register_settings' ] );
    }

    public function ali_register_settings() {
        require_once( __DIR__ . '/inc/feature.php' );
        
        register_setting('ali-addons-for-elementor-settings', 'license_key');

        register_setting('ali-hubspot-group', 'ali-hubspot-access-token');

        register_setting('ali-brevo-group', 'ali-brevo-api-key');

        register_setting('ali-get-response-group', 'ali-get-response-api-key');

        register_setting( 'ali-gs-group', 'ali-gs-client-id' );
        register_setting( 'ali-gs-group', 'ali-gs-client-secret' );

        register_setting( 'ali-google-calendar-group', 'ali-google-calendar-client-id' );
        register_setting( 'ali-google-calendar-group', 'ali-google-calendar-client-secret' );
        register_setting( 'ali-google-calendar-group', 'ali-google-calendar-client-api-key' );

        $features = json_decode( ALI_FEATURES, true );
        foreach ($features as $feature) {
            register_setting( 'ali-addons-features-settings-group', $feature['option'] );
        }
    }
    function elementor_widgets_dependencies() {

        if( (get_option( 'ali-sw', 2 ) == 2 || get_option( 'ali-sw', 2 ) == 1 ) && get_option('ali_license_status') == 'valid') {
            wp_enqueue_script( 'ali-sw-script', plugin_dir_url( __FILE__ ) . 'assets/js/minify/ali-sw.min.js', false, ALI_ADDONS_FOR_ELEMENTOR_VERSION );
            wp_enqueue_style( 'ali-sw-style', plugin_dir_url( __FILE__ ) . 'assets/css/minify/ali-sw.min.css', false, ALI_ADDONS_FOR_ELEMENTOR_VERSION );
        }
    }

    public function init_widgets($widgets_manager) {
        if( (get_option( 'ali-sw', 2 ) == 2 || get_option( 'ali-sw', 2 ) == 1 ) && get_option('ali_license_status') == 'valid') {
            require_once( __DIR__ . '/elements/element-switch-content.php' );
            $widgets_manager->register( new \Ali_sw() );
        }
    }

    public function include_controls_files() {
        Init::init_controls();
    }

    public function include_custom_form_field_files() {
        Init::init_form_field();
    }

    public function include_custom_action_files($form_actions_registrar) {
        Init::add_form_action($form_actions_registrar);
    }

}

Ali_Addons_For_Elementor::instance();





