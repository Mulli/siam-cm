<?php
require_once( __DIR__ . '/ali-custom-tab.php' );

class Ali_International_Tel_Field extends \Elementor\Widget_Base {

    public function __construct() {
        parent::__construct();
        $this->init_control();
    }

    public function get_name() {
        return 'ali-image-select-field';
    }

    protected function init_control() {
        add_action( 'elementor/element/form/section_form_fields/after_section_end', [ $this, 'ali_register_controls' ], 10, 2 );
        add_action( 'elementor/frontend/widget/before_render', [ $this, 'before_render_element'], 10, 1 );
        add_action( 'elementor/widget/before_render_content', [$this, 'before_content'] );
    }
    public function ali_register_controls( $element, $args ) {

        $element->start_controls_section(
            'ali_international_field_section',
            [
                'label' => __( 'Ali International Tel Field', 'ali' ),
                'tab' => Ali_Controls_Manager::TAB_ALI,
            ]
        );

        $element->add_control(
            'ali_international_field_enable',
            [
                'label' => __( 'Enable', 'ali' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => '',
                'description' => __( 'This feature only works on the frontend.', 'ali' ),
                'label_on' => 'Yes',
                'label_off' => 'No',
                'return_value' => 'yes',
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'ali_international_field_id',
            [
                'label' => __( 'Field ID', 'ali' ),
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,
                'description' => __( 'Reload if the field id list are not shown.', 'ali' ),
            ]
        );

        $repeater->add_control(
            'ali_international_default_country',
            [
                'label' => __( 'Default Country', 'ali' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'description' => __( 'Find your country code to set default: https://ip-api.com/', 'ali' ),
            ]
        );

        $element->add_control(
            'ali_international_field_list',
            array(
                'type'    => Elementor\Controls_Manager::REPEATER,
                'fields'  => $repeater->get_controls(),
                'condition' => [
                    'ali_international_field_enable' => 'yes',
                ],
            )
        );

        

        $element->end_controls_section();
    }
    public function before_content($element) {
        $settings = $element->get_settings_for_display();
        if ( isset($settings['ali_international_field_enable']) && $settings['ali_international_field_enable'] === 'yes' ) {
            add_action( 'elementor/frontend/before_enqueue_scripts', [$this, 'ali_register_script'] );
        }
    }

    public function ali_register_script() {
        wp_register_script( 'ali-international-tel-field-script', plugins_url('assets/js/minify/ali-international-tel-field.min.js', dirname( __FILE__ ) ), [ 'jquery' ], ALI_ADDONS_FOR_ELEMENTOR_VERSION );
        wp_enqueue_script( 'ali-international-tel-field-script');
        wp_localize_script( 'ali-international-tel-field-script', 'ali_international_tel_field_params', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) )  );

        wp_register_style( 'ali-international-tel-field-style', plugins_url('assets/css/minify/ali-international-tel-field.min.css', dirname( __FILE__ ) ), [], ALI_ADDONS_FOR_ELEMENTOR_VERSION );
        wp_enqueue_style( 'ali-international-tel-field-style' );
    }

    public function before_render_element($element) {
        $settings = $element->get_settings();
        if(isset($settings['ali_international_field_enable']) && $settings['ali_international_field_enable'] === 'yes'){
            if ( array_key_exists( 'ali_international_field_list',$settings ) ) {
                $list = $settings['ali_international_field_list'];
                if( !empty($list[0]['ali_international_field_id'])  ) {

                    $element->add_render_attribute( '_wrapper', [
                        'data-ali-international-field' => json_encode($list),
                    ] );
                }
            }
        }


    }
}
