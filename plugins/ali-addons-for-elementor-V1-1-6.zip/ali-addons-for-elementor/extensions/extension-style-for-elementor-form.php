<?php
require_once( __DIR__ . '/ali-custom-tab.php' );

class ALi_Style_For_Elementor_Form extends \Elementor\Widget_Base
{

    public function __construct()
    {
        parent::__construct();
        $this->init_control();
    }

    public function get_name()
    {
        return 'ali-style-for-elementor-form';
    }

    public function ali_register_controls($element, $args)
    {

        $element->start_controls_section(
            'ali_form_style_section',
            [
                'label' => __('Ali Form Style', 'ali'),
                'tab' => Ali_Controls_Manager::TAB_ALI,
            ]
        );

        $element->add_control(
            'ali_form_style_enable',
            [
                'label' => __('Enable', 'ali'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => '',
                'label_on' => 'Yes',
                'label_off' => 'No',
                'return_value' => 'yes',
            ]
        );

        $element->add_responsive_control(
            'ali_form_style_text_align',
            [
                'label' => __( 'Input Text Align', 'ali' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'ali' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'ali' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'ali' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-field-group:not(.elementor-field-type-upload) .elementor-field:not(.elementor-select-wrapper)'=> 'text-align: {{VALUE}};'
                ],
                'condition' => [
                    'ali_form_style_enable' => 'yes',
                ],
            ]
        );

        $element->add_responsive_control(
            'ali_form_style_input_padding',
            [
                'label' => __('Input Padding', 'ali'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .elementor-field-group:not(.elementor-field-type-upload) .elementor-field:not(.elementor-select-wrapper)' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'ali_form_style_enable' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ali_form_style_input_placeholder_color',
            [
                'label' => __('Input Placeholder Color', 'ali'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#333333',
                'selectors' => [
                    '{{WRAPPER}} .elementor-field-group:not(.elementor-field-type-upload) .elementor-field:not(.elementor-select-wrapper)::placeholder' => 'color: {{VALUE}}; opacity: 1;',
                    '{{WRAPPER}} .elementor-field-group:not(.elementor-field-type-upload) .elementor-field:not(.elementor-select-wrapper)::-webkit-input-placeholder' => 'color: {{VALUE}}; opacity: 1;',
                    '{{WRAPPER}} .elementor-field-group:not(.elementor-field-type-upload) .elementor-field:not(.elementor-select-wrapper)::-moz-placeholder' => 'color: {{VALUE}}; opacity: 1;',
                    '{{WRAPPER}} .elementor-field-group:not(.elementor-field-type-upload) .elementor-field:not(.elementor-select-wrapper):-ms-input-placeholder' => 'color: {{VALUE}}; opacity: 1;',
                    '{{WRAPPER}} .elementor-field-group:not(.elementor-field-type-upload) .elementor-field:not(.elementor-select-wrapper):-moz-placeholder' => 'color: {{VALUE}}; opacity: 1;',
                ],
                'condition' => [
                    'ali_form_style_enable' => 'yes',
                ],
            ]
        );

        $element->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'ali_form_style_input_box_shadow',
                'label' => __('Input Box Shadow', 'ali'),
                'selector' => '{{WRAPPER}} .elementor-field-group:not(.elementor-field-type-upload) .elementor-field:not(.elementor-select-wrapper)',
                'condition' => [
                    'ali_form_style_enable' => 'yes',
                ],
            ]
        );

        $element->add_responsive_control(
            'ali_form_style_button_margin',
            [
                'label' => __('Button Margin', 'ali'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .elementor-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'ali_form_style_enable' => 'yes',
                ],
            ]
        );

        $element->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'ali_form_style_button_box_shadow',
                'label' => __('Button Box Shadow', 'ali'),
                'selector' => '{{WRAPPER}} .elementor-button',
                'condition' => [
                    'ali_form_style_enable' => 'yes',
                ],
            ]
        );

        $element->end_controls_section();
    }

    protected function init_control() {
        add_action( 'elementor/element/form/section_messages_style/after_section_end', [ $this, 'ali_register_controls' ], 10, 2 );
    }

}
