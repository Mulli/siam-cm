<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

class Ali_Get_Response extends \ElementorPro\Modules\Forms\Classes\Action_Base {

    public function get_name() {
        return 'get_response';
    }

    public function get_label() {
        return esc_html__( 'Ali GetResponse', 'ali' );
    }

    public function register_settings_section( $widget ) {

        $widget->start_controls_section(
            'section_ali_getresponse',
            [
                'label' => esc_html__( 'Ali GetResponse', 'ali' ),
                'condition' => [
                    'submit_actions' => $this->get_name(),
                ],
            ]
        );


        $widget->add_control(
            'getresponse_get_data_list',
            [
                'type' => \Elementor\Controls_Manager::RAW_HTML,
                'raw' => __( '<button data-ali-getresponse-get-data-list class="ali-admin-button-ajax elementor-button elementor-button-default" type="button">Get List&ensp;<i class="fas fa-spinner fa-spin"></i></button><div id="ali-getresponse-list"></div>', 'ali' ),
            ]
        );

        $widget->add_control(
            'getresponse_campaign_id',
            [
                'label' => __( 'Campaign ID', 'ali' ),
                'type' => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $widget->add_control(
            'getresponse_get_data_custom_fields',
            [
                'type' => \Elementor\Controls_Manager::RAW_HTML,
                'raw' => __( '<button data-ali-getresponse-get-data-custom-fields class="ali-admin-button-ajax elementor-button elementor-button-default" type="button">Get Custom Fields&ensp;<i class="fas fa-spinner fa-spin"></i></button><div id="ali-getresponse-custom-fields"></div>', 'ali' ),
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'getresponse_field_mapping_multiple',
            [
                'label' => __( 'Multiple Field?', 'ali' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'ali' ),
                'label_off' => __( 'No', 'ali' ),
                'return_value' => 'yes',
                'default' => '',
            ]
        );

        $repeater->add_control(
            'getresponse_field_mapping_tag_name',
            [
                'label' => __( 'Tag Name', 'ali' ),
                'label_block' => true,
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => __( 'E.g email, name, last_name', 'ali' ),
            ]
        );

        $repeater->add_control(
            'getresponse_field_mapping_field_shortcode',
            [
                'label_block' => true,
                'type' => \Elementor\aliCustomControls\Select_Control::Select,
                'get_fields' => true,
            ]
        );

        $widget->add_control(
            'getresponse_field_mapping_list',
            array(
                'type'    => Elementor\Controls_Manager::REPEATER,
                'fields'  => $repeater->get_controls(),
                'title_field' => '{{{ getresponse_field_mapping_tag_name }}} = {{{ getresponse_field_mapping_field_shortcode }}}',
                'label' => __( 'Field Mapping', 'ali' ),
            )
        );

        $widget->end_controls_section();

    }

    public function run( $record, $ajax_handler ) {
        $settings = $record->get( 'form_settings' );
        $raw_fields = $record->get( 'fields' );
        $fields = [];

        foreach ( $raw_fields as $id => $field ) {
            $fields[ $id ] = $field['value'];
        }


        $getresponse_api_key = get_option('ali-get-response-api-key');

        $getresponse_url_add_contact = "https://api.getresponse.com/v3/contacts/";

        $items = $settings['getresponse_field_mapping_list'];

        if(!empty($items)){
            $get_response_fields = array();
            foreach($items as $item){
                $key = $item['getresponse_field_mapping_tag_name'];
                $shortcode = $item['getresponse_field_mapping_field_shortcode'];
                if (!empty($key) && !empty($shortcode)) {
                    if($key == 'email' || $key ==  "name"){
                        $get_response_fields[$key] = $fields[$item['getresponse_field_mapping_field_shortcode']];
                    }elseif($item['getresponse_field_mapping_multiple'] == 'yes'){
                        $get_response_fields['customFieldValues'][] = array(
                            'customFieldId' => $key,
                            'values' =>  $fields[$item['getresponse_field_mapping_field_shortcode']],
                        );
                    }
                    else{
                        $get_response_fields['customFieldValues'][] = array(
                            'customFieldId' => $key,
                            'value' =>  array(
                                $fields[$item['getresponse_field_mapping_field_shortcode']]
                            )
                        );
                    }
                }
            }
            //$get_response_fields['ipAddress'] = $_POST['remote_ip'];
            $get_response_fields['campaign'] = [
                'campaignId' => $settings['getresponse_campaign_id']
            ];
            $gs_data = array(
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'X-Auth-Token' => 'api-key '.$getresponse_api_key,
                ),
                'body' => json_encode($get_response_fields)
            );

            $response = wp_remote_post($getresponse_url_add_contact, $gs_data);

        }


    }

    public function on_export( $element ) {

        return $element;

    }

}