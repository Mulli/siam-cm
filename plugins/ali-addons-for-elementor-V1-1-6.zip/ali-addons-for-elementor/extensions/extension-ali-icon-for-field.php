<?php


namespace Elementor;
use Elementor\Controls_Manager;

class Icons {

    public $excluded_types = ['reset', 'honeypot', 'recaptcha', 'recaptcha_v3', 'hidden', 'html'];

    public function __construct() {
        add_filter( 'elementor_pro/forms/render/item', [ $this, 'render' ], 10, 3 );
        add_action( 'elementor-pro/forms/pre_render', [$this, 'before_content'] );
        add_action( 'elementor/element/form/section_form_fields/before_section_end', [ $this, 'ali_custom_field_control' ], 100, 2 );
        add_action('elementor/element/form/section_form_style/after_section_end', [$this, 'add_controls']);

    }
    public function ali_register_script() {
        wp_register_script( 'ali-icon-field-script', plugins_url('assets/js/minify/ali-icon-for-field.min.js', dirname( __FILE__ ) ), [ 'jquery' ], ALI_ADDONS_FOR_ELEMENTOR_VERSION);
        wp_enqueue_script( 'ali-icon-field-script');
        wp_register_style( 'ali-icon-field-style', plugins_url('assets/css/minify/ali-icon-for-field.min.css', dirname( __FILE__ ) ), [], ALI_ADDONS_FOR_ELEMENTOR_VERSION );
        wp_enqueue_style( 'ali-icon-field-style' );
    }
    public function before_content($element){
        if(!empty($element['form_fields']) && is_array($element['form_fields'])){
            array_walk($element['form_fields'], function($field, $key){
                if($field['field_icon_position'] === 'elementor-field-label' || $field['field_icon_position'] === 'elementor-field' ){
                    add_action( 'elementor/frontend/before_enqueue_scripts', [$this, 'ali_register_script'] );
                }
            });
        }
    }
    public function ali_custom_field_control($element, $args ) {
        $elementor = \Elementor\Plugin::instance();
        $control_data = $elementor->controls_manager->get_control_from_stack( $element->get_name(), 'form_fields' );

        if ( is_wp_error( $control_data ) ) {
            return;
        }
        $field_new_controls=[];
        $field_new_controls['field_icon_position'] = array(
                'name' => 'field_icon_position',
                'label' => esc_html__('Icon', 'ali'),
                'separator' => 'before',
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'no-icon' => [
                        'title' => esc_html__('No Icon', 'ali'),
                        'icon' => 'eicon-close',
                    ],
                    'elementor-field' => [
                        'title' => esc_html__('Add Icon', 'ali'),
                        'icon' => 'eicon-select',
                    ]
                ],
                'toggle' => false,
                'default' => 'no-icon',
                'condition' => [
                    'field_type!' => $this->excluded_types,
                ],
                'tab'          => 'form_fields_content_tab',
                'tabs_wrapper' => 'form_fields_tabs',
                'inner_tab'    => 'form_fields_content_tab',
            );
            $field_new_controls['field_icon'] = array(
                'name' => 'field_icon',
                'label' => esc_html__('Select Icon', 'elementor'),
                'type' => Controls_Manager::ICONS,
                'label_block' => true,
                'fa4compatibility' => 'icon',
                'condition' => [
                    'field_type!' => $this->excluded_types,
                    'field_icon_position!' => 'no-icon',
                ],
                'tab'          => 'form_fields_content_tab',
                'tabs_wrapper' => 'form_fields_tabs',
                'inner_tab'    => 'form_fields_content_tab',
            );

        $field_control_data['fields'] = $control_data['fields'] + $field_new_controls;
        $element->update_control('form_fields', $field_control_data);
    }

    public function add_controls($widget) {

        $widget->start_controls_section(
            'ali_icon_for_field_field_section',
            [
                'label' => __( 'Ali Icons', 'ali' ),
                'tab' => Controls_Manager::TAB_STYLE

            ]
        );
        $widget->add_control(
            'field_icon_heading',
            [
                'label' => esc_html__('Field Icon', 'ali'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $widget->add_control(
            'field_icon_color',
            [
                'label' => esc_html__('Color', 'ali'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ali-icon-for-field' => 'color: {{VALUE}};',
                ],
            ]
        );
        $widget->add_control(
            'field_icon_typography',
            [
                'label' => esc_html__('Size', 'ali'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 10,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .ali-icon-for-field' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $widget->end_controls_section();
    }

    public function render( $item, $item_index, $form  ) {
        if ( !empty($item['field_icon']) && !in_array( $item['field_type'], $this->excluded_types ) ) {
            $form->add_render_attribute( 'input' . $item_index, 'data-ali-icon-for-field', $item['field_icon'] );
            $form->add_render_attribute('textarea' . $item_index, [
                'data-ali-icon-for-textarea-field' => $item['field_icon'],
            ]);
            $form->add_render_attribute('select' . $item_index, 'data-ali-icon-for-field', $item['field_icon']);
        }
        return $item;
    }

}
