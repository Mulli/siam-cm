<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

class Ali_Hubspot extends \ElementorPro\Modules\Forms\Classes\Action_Base {

    public function get_name() {
        return 'hubspot';
    }

    public function get_label() {
        return esc_html__( 'Hubspot', 'ali' );
    }

    public function register_settings_section( $widget ) {

        $widget->start_controls_section(
            'section_ali_hubspot',
            [
                'label' => esc_html__( 'Ali Hubspot', 'ali' ),
                'condition' => [
                    'submit_actions' => $this->get_name(),
                ],
            ]
        );

        $widget->add_control(
            'ali_hubspot_enable',
            [
                'label' => __( 'Enable', 'ali' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => '',
                'label_on' => 'Yes',
                'label_off' => 'No',
                'return_value' => 'yes',
            ]
        );

        $widget->add_control(
            'ali_hubspot_get_group',
            [
                'type' => \Elementor\Controls_Manager::RAW_HTML,
                'raw' => __( '<button data-ali-hubspot-get-group-list class="ali-admin-button-ajax elementor-button elementor-button-default" type="button">Get Group List<i class="fas fa-spinner fa-spin"></i></button><div class="ali-hubspot-group-list"></div>', 'ali' ),
                'condition' => [
                    'ali_hubspot_enable' => 'yes',
                ],
            ]
        );

        $widget->add_control(
            'ali_hubspot_group_key',
            [
                'label' => __( 'Group Key', 'ali' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => __( '', 'ali' ),
                'placeholder' => __( 'Enter the group key here', 'ali' ),
                'condition' => [
                    'ali_hubspot_enable' => 'yes',
                ],
            ]
        );
        
        $widget->add_control(
            'ali_hubspot_get_property',
            [
                'type' => \Elementor\Controls_Manager::RAW_HTML,
                'raw' => __( '<button data-ali-hubspot-get-property-list class="ali-admin-button-ajax elementor-button elementor-button-default" type="button">Get Property List<i class="fas fa-spinner fa-spin"></i></button><div class="ali-hubspot-property-list"></div>', 'ali' ),
                'condition' => [
                    'ali_hubspot_enable' => 'yes',
                ],
            ]
        );


        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'ali_hubspot_property_name',
            [
                'label' => __( 'Property Name', 'ali' ),
                'label_block' => true,
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => __( 'E.g email, name, last_name', 'ali' ),

            ]
        );

        $repeater->add_control(
            'ali_hubspot_field_id',
            [
                'label' => __( 'Field ID', 'ali' ),
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,
                'description' => __( 'Reload if the field id list are not shown.', 'ali' ),
            ]
        );

        $widget->add_control(
            'ali_hubspot_property_list',
            [
                'type'    => Elementor\Controls_Manager::REPEATER,
                'fields'  => $repeater->get_controls(),
                'title_field' => '{{{ali_hubspot_property_name}}}',
                'label' => __( 'Property', 'ali' ),
                'condition' => [
                    'ali_hubspot_enable' => 'yes',
                ],
            ]
        );

        $widget->end_controls_section();

    }

    public function run( $record, $ajax_handler ) {
        $settings = $record->get( 'form_settings' );
        $raw_fields = $record->get( 'fields' );
        $fields = [];

        foreach ( $raw_fields as $id => $field ) {
            $fields[ $id ] = $field['value'];
        }

        $hubspot_url = 'https://api.hubapi.com/contacts/v1/contact/';
        $hubspot_access_token = get_option('ali-hubspot-access-token');
        $hubspot_body_data = [];
        $hubspot_properties = $settings['ali_hubspot_property_list'];
        foreach ( $hubspot_properties as $item ) {
            $hubspot_body_data['properties'][] = [
                'property' => $item['ali_hubspot_property_name'],
                'value' => $fields[$item['ali_hubspot_field_id']],
            ];

        }

        $hubspot_data = array(
            'headers'     => array(
                'Authorization'=>'Bearer '.$hubspot_access_token,
                'Content-Type'=> 'application/json'
            ),
            'body' => json_encode($hubspot_body_data)
        );

        // Send the request.
        wp_remote_post($hubspot_url, $hubspot_data);

    }

    public function on_export( $element ) {

        return $element;

    }

}