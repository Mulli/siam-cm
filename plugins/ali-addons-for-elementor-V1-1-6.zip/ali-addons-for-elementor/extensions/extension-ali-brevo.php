<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

class Ali_Brevo extends \ElementorPro\Modules\Forms\Classes\Action_Base {

    public function get_name() {
        return 'brevo';
    }

    public function get_label() {
        return esc_html__( 'Brevo', 'ali' );
    }

    public function register_settings_section( $widget ) {

        $widget->start_controls_section(
            'section_ali_brevo',
            [
                'label' => esc_html__( 'Brevo', 'ali' ),
                'condition' => [
                    'submit_actions' => $this->get_name(),
                ],
            ]
        );
        
//        $widget->add_control(
//            'brevo_api_update_contact',
//            [
//                'label' => __( 'Update Contact?', 'ali' ),
//                'type' => \Elementor\Controls_Manager::SWITCHER,
//                'label_on' => __( 'Yes', 'ali' ),
//                'label_off' => __( 'No', 'ali' ),
//                'return_value' => 'yes',
//                'default' => '',
//            ]
//        );
//        $widget->add_control(
//            'brevo_api_acceptance_field',
//            [
//                'label' => __( 'Acceptance Field?', 'ali' ),
//                'type' => \Elementor\Controls_Manager::SWITCHER,
//                'label_on' => __( 'Yes', 'ali' ),
//                'label_off' => __( 'No', 'ali' ),
//                'return_value' => 'yes',
//                'default' => '',
//            ]
//        );
        $widget->add_control(
            'brevo_api_acceptance_field_shortcode',
            [
                'label' => __( 'Acceptance Field Shortcode', 'ali' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'get_fields' => true,
                'condition' => [
                    'brevo_api_acceptance_field' => 'yes'
                ]
            ]
        );
        $widget->add_control(
            'brevo_list_ids',
            [
                'label' => __( 'List ID', 'ali' ),
                'type' => \Elementor\Controls_Manager::TEXT,
            ]
        );
        $widget->add_control(
            'brevo_api_get_list',
            [
                'type' => \Elementor\Controls_Manager::RAW_HTML,
                'raw' => __( '<button data-ali-brevo-get-list class="ali-admin-button-ajax elementor-button elementor-button-default" type="button">Get Attributes <i class="fas fa-spinner fa-spin"></i></button>', 'ali' ),
            ]
        );
        $widget->add_control(
            'brevo_api_get_attr',
            [
                'type' => \Elementor\Controls_Manager::RAW_HTML,
                'raw' => __( '<div class="ali-brevo-attribute-result" data-ali-brevo-api-get-attributes-result></div>', 'ali' ),
            ]
        );
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'brevo_tagname', [
                'label' => __( 'Attribute Name', 'ali' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'brevo_shortcode', [
                'label' => __( 'Field ID', 'ali' ),
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,
                'label_block' => true,
                'description' => __( 'Reload if the field id list are not shown.', 'ali' ),
            ]
        );

        $widget->add_control(
            'brevo_fields_map',
            [
                'label' => __( 'Fields Mapping', 'ali' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'brevo_tagname' => __( 'email', 'ali' ),
                    ],
                ],
                'title_field' => '{{{ brevo_tagname }}} --- {{{ brevo_shortcode }}}',
            ]
        );
        $widget->end_controls_section();


    }

    public function run( $record, $ajax_handler ) {
        $settings = $record->get( 'form_settings' );
        $raw_fields = $record->get( 'fields' );
        $fields = [];

        foreach ( $raw_fields as $id => $field ) {
            $fields[ $id ] = $field['value'];
        }

        $brevo_url = 'https://api.brevo.com/v3/contacts';
        $brevo_api = get_option('ali-brevo-api-key');
        $brevo_lists = explode(',', $settings['brevo_list_ids']);

        foreach($brevo_lists as $key => $list){
            $brevo_lists[$key] = intval($list);
        }
        $brevo_field_mapping_list = $settings['brevo_fields_map'];
        if(!empty($brevo_field_mapping_list)){
            $data_brevo = [];

            foreach($brevo_field_mapping_list as $item){
                if($item['brevo_tagname'] == 'email'){
                    $data_brevo['email'] = $fields[$item['brevo_shortcode']];
                }else{
                    $data_brevo['attributes'][$item['brevo_tagname']] = $fields[$item['brevo_shortcode']];
                }
            }
            $data_brevo['listIds'] = $brevo_lists;
            $data_brevo = json_encode($data_brevo);
            $brevo_data = array(
                'headers'     => array(
                    'Accept'=>'application/json',
                    'Content-Type'=> 'application/json',
                    'api-key'=> $brevo_api
                ),
                'body' => $data_brevo
            );

            // Send the request.
            $response = wp_remote_post($brevo_url, $brevo_data);
        }

    }

    public function on_export( $element ) {

        return $element;

    }

}