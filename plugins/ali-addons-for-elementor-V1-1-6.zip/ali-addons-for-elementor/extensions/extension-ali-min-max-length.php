<?php
namespace Elementor;

use Elementor\Controls_Manager;

class Ali_Min_Max_Length_For_Field {
    public $allowed_fields = [
        'textarea',
    ];

    public function __construct() {
        add_filter( 'elementor_pro/forms/render/item', [ $this, 'render' ], 10, 3 );
        add_action( 'elementor/element/form/section_form_fields/before_section_end', [ $this, 'ali_custom_field_control' ], 100, 2 );
    }

    public function ali_custom_field_control( $element, $args ) {
        $elementor = \Elementor\Plugin::instance();
        $control_data = $elementor->controls_manager->get_control_from_stack( $element->get_name(), 'form_fields' );

        if ( is_wp_error( $control_data ) ) {
            return;
        }
        $field_new_controls = [
            'form_fields_ali_min_max_length_enabled' => [
                'name'         => 'form_fields_ali_min_max_length_enabled',
                'label'        => __('Enable Min/Max Length', 'ali'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => 'Yes',
                'label_off'    => 'No',
                'tab'          => 'form_fields_content_tab',
                'tabs_wrapper' => 'form_fields_tabs',
                'inner_tab'    => 'form_fields_content_tab',
                'conditions' => [
                    'terms' => [
                        [
                            'name'     => 'field_type',
                            'operator' => 'in',
                            'value'    => ['textarea']
                        ]
                    ]
                ],
            ],
            'form_fields_ali_min_length' => [
                'name'         => 'form_fields_ali_min_length',
                'label'        => __('Min Length', 'ali'),
                'type'         => Controls_Manager::NUMBER,
                'tab'          => 'form_fields_content_tab',
                'tabs_wrapper' => 'form_fields_tabs',
                'inner_tab'    => 'form_fields_content_tab',
                'conditions' => [
                    'terms' => [
                        [
                            'name'     => 'form_fields_ali_min_max_length_enabled',
                            'operator' => '===',
                            'value' => 'yes',
                        ]
                    ]
                ],
            ],
            'form_fields_ali_max_length' => [
                'name'         => 'form_fields_ali_max_length',
                'label'        => __('Max Length', 'ali'),
                'type'         => Controls_Manager::NUMBER,
                'tab'          => 'form_fields_content_tab',
                'tabs_wrapper' => 'form_fields_tabs',
                'inner_tab'    => 'form_fields_content_tab',
                'conditions' => [
                    'terms' => [
                        [
                            'name'     => 'form_fields_ali_min_max_length_enabled',
                            'operator' => '===',
                            'value' => 'yes',
                        ]
                    ]
                ],
            ],
        ];

        $field_control_data['fields'] = $control_data['fields'] + $field_new_controls;
        $element->update_control('form_fields', $field_control_data);
    }

    public function render( $field, $field_index, $form_widget ) {
        if ( ! empty( $field['form_fields_ali_min_max_length_enabled'] ) && ! empty( $field['form_fields_ali_min_length'] ) && in_array( $field['field_type'], $this->allowed_fields ) ) {
            $form_widget->add_render_attribute( 'textarea' . $field_index, 'minlength', $field['form_fields_ali_min_length'] );
        }

        if ( ! empty( $field['form_fields_ali_min_max_length_enabled'] ) && ! empty( $field['form_fields_ali_max_length'] ) && in_array( $field['field_type'], $this->allowed_fields ) ) {
            $form_widget->add_render_attribute( 'textarea' . $field_index, 'maxlength', $field['form_fields_ali_max_length'] );
        }
        return $field;
    }
}
new Ali_Min_Max_Length_For_Field();
