<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Ali_Register_User extends \ElementorPro\Modules\Forms\Classes\Action_Base
{

    public function get_name()
    {
        return 'register_user';
    }

    public function get_label()
    {
        return esc_html__('Ali Register User', 'ali');
    }

    public function register_settings_section($widget)
    {

        $widget->start_controls_section(
            'section_register',
            [
                'label' => __('Ali Register User', 'ali'),
                'condition' => [
                    'submit_actions' => $this->get_name(),
                ],
            ]
        );

        global $wp_roles;
        $roles = $wp_roles->roles;
        $roles_array = array();
        foreach ($roles as $key => $value) {
            $roles_array[$key] = $value['name'];
        }

        $widget->add_control(
            'register_role',
            [
                'label' => __('Role', 'ali'),
                'label_block' => true,
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => $roles_array,
                'default' => 'subscriber',
            ]
        );

        $widget->add_control(
            'ali_login_after_register_enable',
            [
                'label' => __('Login After Submit', 'ali'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => '',
                'label_on' => 'Yes',
                'label_off' => 'No',
                'return_value' => 'yes',
            ]
        );

        $widget->add_control(
            'register_email',
            [
                'label' => __('Email (Required)', 'ali'),
                'label_block' => true,
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,            ]
        );

        $widget->add_control(
            'register_username',
            [
                'label' => __('Username (Required)', 'ali'),
                'label_block' => true,
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,            ]
        );

        $widget->add_control(
            'register_password',
            [
                'label' => __('Password (Required)', 'ali'),
                'label_block' => true,
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,
            ]
        );

        /*$widget->add_control(
            'register_password_confirm',
            [
                'label' => __('Confirm Password Field ID', 'ali'),
                'label_block' => true,
                'type' => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $widget->add_control(
            'register_password_confirm_message',
            [
                'label' => __('Wrong Password Message', 'ali'),
                'label_block' => true,
                'type' => \Elementor\Controls_Manager::TEXT,
            ]
        );*/

        $widget->add_control(
            'register_first_name',
            [
                'label' => __('First Name', 'ali'),
                'label_block' => true,
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,            ]
        );

        $widget->add_control(
            'register_last_name',
            [
                'label' => __('Last Name', 'ali'),
                'label_block' => true,
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'register_user_meta',
            [
                'label' => __('Data Source', 'ali'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '' => __('Choose', 'ali'),
                    'meta' => __('User Meta Key', 'ali'),
                    'acf' => __('ACF Field', 'ali'),
                    'metabox' => __('MetaBox Field', 'ali'),
                    'toolset' => __('Toolset Field', 'ali'),
                ],
            ]
        );

        $repeater->add_control(
            'register_user_meta_type',
            [
                'label' => __('Data Type', 'ali'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'text' => __('Text,Textarea,Number,Email,Url,Password', 'ali'),
                    'image' => __('Image', 'ali'),
                    'gallery' => __('Gallery', 'ali'),
                    'select' => __('Select', 'ali'),
                    'radio' => __('Radio', 'ali'),
                    'checkbox' => __('Checkbox', 'ali'),
                    'true_false' => __('True / False', 'ali'),
                    'date' => __('Date', 'ali'),
                    'time' => __('Time', 'ali'),
                ],
                'default' => 'text',
                'condition' => [
                    'register_user_meta' => ['acf', 'metabox', 'toolset']
                ],
            ]
        );

        $repeater->add_control(
            'register_user_meta_key',
            [
                'label' => __('Meta Key', 'ali'),
                'type' => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $repeater->add_control(
            'register_user_meta_field_id',
            [
                'label' => __('Field ID', 'ali'),
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,
                'description' => __( 'Reload if the field id list are not shown.', 'ali' ),
            ]
        );

        $widget->add_control(
            'register_user_meta_list',
            [
                'type' => Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ register_user_meta_key }}} - {{{ register_user_meta_field_id }}}',
                'label' => __('User Meta Data', 'ali'),
            ]
        );

        $widget->end_controls_section();


    }

    public function run($record, $ajax_handler)
    {

        $settings = $record->get('form_settings');
        $raw_fields = $record->get('fields');
        $fields = [];

        foreach ($raw_fields as $id => $field) {
            $fields[$id] = $field['value'];
        }
        if (!empty($settings['register_email']) && !empty($settings['register_username']) && !empty($settings['register_password'])) {
            $register_email = $fields[$settings['register_email']];
            $register_username = $fields[$settings['register_username']];
            $register_password = $fields[$settings['register_password']];
            //$register_password_confirm = $settings['register_password_confirm'];
            $register_first_name = $fields[$settings['register_first_name']];
            $register_last_name = $fields[$settings['register_last_name']];
            $register_message = '';

            /*if (!empty($register_password_confirm) && $register_password != $register_password_confirm) {
                $register_message = $settings['register_password_confirm_message'];
                $failed = true;
            } else {*/
                if (!empty($register_email) && !empty($register_username) && !empty($register_password)) {
                    $register_user = wp_create_user($register_username, $register_password, $register_email);
                    if (is_wp_error($register_user)) {
                        $failed = true;
                        $register_message = $register_user->get_error_message();

                    } else {
                        wp_update_user(array(
                            'ID' => $register_user,
                            'role' => $settings['register_role']
                        ));

                        if (!empty($settings['register_user_meta_list'])) {
                            foreach ($settings['register_user_meta_list'] as $user_meta_item) {
                                if (!empty($user_meta_item['register_user_meta_key']) && !empty($user_meta_item['register_user_meta_field_id'])) {
                                    update_user_meta($register_user, $user_meta_item['register_user_meta_key'], $fields[$user_meta_item['register_user_meta_field_id']]);
                                }

                                if (!empty($user_meta_item['register_user_meta']) && !empty($user_meta_item['register_user_meta_field_id'])) {
                                    $register_user_meta = $user_meta_item['register_user_meta'];
                                    $register_user_meta_value = '';

                                    if ($user_meta_item['register_user_meta'] == 'meta' || $user_meta_item['register_user_meta'] == 'acf' || $user_meta_item['register_user_meta'] == 'metabox') {
                                        if (!empty($user_meta_item['register_user_meta_key'])) {
                                            $register_user_meta_key = $user_meta_item['register_user_meta_key'];
                                        }
                                    }

                                    if ($user_meta_item['register_user_meta'] == 'toolset') {
                                        if (!empty($user_meta_item['register_user_meta_key'])) {
                                            $register_user_meta_key = 'wpcf-' . $user_meta_item['register_user_meta_key'];
                                        }
                                    }

                                    if ($register_user_meta == 'acf') {
                                        $meta_type = $user_meta_item['register_user_meta_type'];
                                        $custom_field_value = $fields[$user_meta_item['register_user_meta_field_id']];

                                        if ($meta_type == 'image') {
                                            $image_array = explode(',', $custom_field_value);
                                            $image_id = attachment_url_to_postid($image_array[0]);
                                            if (!empty($image_id)) {
                                                $custom_field_value = $image_id;
                                            }
                                        }

                                        if ($meta_type == 'gallery') {
                                            $images_array = explode(',', $custom_field_value);
                                            $images_id = array();
                                            foreach ($images_array as $images_item) {
                                                if (!empty($images_item)) {
                                                    $image_id = attachment_url_to_postid($images_item);
                                                    if (!empty($image_id)) {
                                                        $images_id[] = $image_id;
                                                    }
                                                }
                                            }
                                            if (!empty($images_id)) {
                                                $custom_field_value = $images_id;
                                            }
                                        }

                                        if ($meta_type == 'select' && strpos($custom_field_value, ',') !== false || $meta_type == 'checkbox') {
                                            $custom_field_value = explode(',', $custom_field_value);
                                        }

                                        if ($meta_type == 'true_false') {
                                            $custom_field_value = !empty($custom_field_value) ? 1 : 0;
                                        }

                                        if ($meta_type == 'date') {
                                            $time = strtotime($custom_field_value);

                                            if (empty($custom_field_value)) {
                                                $custom_field_value = '';
                                            } else {
                                                $custom_field_value = date('Ymd', $time);
                                            }
                                        }

                                        if ($meta_type == 'time') {
                                            $time = strtotime($custom_field_value);

                                            if (empty($custom_field_value)) {
                                                $custom_field_value = '';
                                            } else {
                                                $custom_field_value = date('H:i:s', $time);
                                            }
                                        }
                                        update_field($register_user_meta_key, $custom_field_value, 'user_' . $register_user);
                                    } elseif (function_exists('rwmb_set_meta') && $register_user_meta == 'metabox') {
                                        $meta_type = $user_meta_item['register_user_meta_type'];
                                        $custom_field_value = $fields[$user_meta_item['register_user_meta_field_id']];

                                        if ($meta_type == 'image') {
                                            $image_array = explode(',', $custom_field_value);
                                            $image_id = attachment_url_to_postid($image_array[0]);
                                            if (!empty($image_id)) {
                                                $custom_field_value = $image_id;
                                            }
                                            update_user_meta($register_user, $register_user_meta_key, $custom_field_value);
                                        }

                                        if ($meta_type == 'gallery') {
                                            $images_array = explode(',', $custom_field_value);
                                            $images_id = '';
                                            foreach ($images_array as $images_item) {
                                                if (!empty($images_item)) {
                                                    $image_id = attachment_url_to_postid($images_item);
                                                    if (!empty($image_id)) {
                                                        $images_id .= $image_id . ',';
                                                    }
                                                }
                                            }
                                            if (!empty($images_id)) {
                                                $custom_field_value = explode(',', $images_id);
                                            }
                                        }

                                        if ($meta_type == 'date') {
                                            $time = strtotime($custom_field_value);
                                            if (empty($custom_field_value)) {
                                                $custom_field_value = '';
                                            } else {
                                                $custom_field_value = date('Y-m-d', $time);
                                            }
                                        }

                                        if ($meta_type == 'time') {
                                            $time = strtotime($custom_field_value);
                                            $custom_field_value = date('H:i', $time);
                                        }

                                        if ($meta_type == 'select') {
                                            if (strpos($custom_field_value, ',') !== false) {
                                                $custom_field_value = explode(',', $custom_field_value);
                                            }
                                        }

                                        if ($meta_type == 'checkbox') {
                                            $custom_field_value = explode(',', $custom_field_value);
                                        }

                                        rwmb_set_meta($register_user, $register_user_meta_key, $custom_field_value, $custom_field_value);

                                    } elseif (function_exists('wpcf_admin_fields_get_field') && $register_user_meta == 'toolset') {
                                        $meta_type = $user_meta_item['register_user_meta_type'];
                                        $custom_field_value = $fields[$user_meta_item['register_user_meta_field_id']];

                                        if ($meta_type == 'image') {
                                            $image_array = explode(',', $custom_field_value);
                                            if (!empty($image_array)) {
                                                update_user_meta($register_user, $register_user_meta_key, $image_array[0]);
                                            }
                                        } elseif ($meta_type == 'gallery') {
                                            $images_array = explode(',', $custom_field_value);
                                            delete_user_meta($register_user, $register_user_meta_key);
                                            foreach ($images_array as $images_item) {
                                                if (!empty($images_item)) {
                                                    add_user_meta($register_user, $register_user_meta_key, $images_item);
                                                }
                                            }
                                        } elseif ($meta_type == 'checkbox') {
                                            $custom_field_value = explode(',', $custom_field_value);

                                            $field_toolset = wpcf_admin_fields_get_field($user_meta_item['register_user_meta_key']);

                                            if (isset($field_toolset['data']['options'])) {
                                                $res = array();
                                                foreach ($field_toolset['data']['options'] as $key => $option) {
                                                    if (in_array($option['set_value'], $custom_field_value)) {
                                                        $res[$key] = $option['set_value'];
                                                    }
                                                }
                                                update_post_meta($register_user, $register_user_meta_key, $res);
                                            }
                                        } elseif ($meta_type == 'date') {
                                            $custom_field_value = strtotime($custom_field_value);
                                            update_user_meta($register_user, $register_user_meta_key, $custom_field_value);
                                        } else {

                                            update_user_meta($register_user, $register_user_meta_key, $custom_field_value);

                                        }
                                    } else {
                                        update_user_meta($register_user, $register_user_meta_key, $fields[$user_meta_item['register_user_meta_field_id']]);
                                    }
                                }
                            }
                        }

                        if (!empty($register_first_name) && !empty($register_last_name)) {
                            wp_update_user(array(
                                'ID' => $register_user,
                                'first_name' => $register_first_name,
                                'last_name' => $register_last_name
                            ));
                        }
                        if (!empty($settings['ali_login_after_register_enable']) && $settings['ali_login_after_register_enable'] == 'yes') {
                            $register_creds = array(
                                'user_login' => $register_username,
                                'user_password' => $register_password,
                                'remember' => true,
                            );

                            $register_signon = wp_signon($register_creds); //sign in the new user
                        }
                    }
                } else {
                    $failed = true;
                }
            /*}*/
        } else {
            $failed = true;
        }


    }

    public function on_export($element)
    {

        return $element;

    }

}