<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Ali_Google_Calendar extends \ElementorPro\Modules\Forms\Classes\Action_Base{

    public function get_name()
    {
        return 'gg_calendar';
    }

    public function get_label()
    {
        return esc_html__('Ali Google Calendar', 'ali');
    }

    public function register_settings_section($widget)
    {
        $cld_array = [];
        $cld_list = get_option('ali-gg-cld-list');
        if (!empty($cld_list)) {
            foreach ($cld_list->items as $item) {
                $cld_array[$item->id] = $item->summary;
            }
        }

        $widget->start_controls_section(
            'section_ali_gg_calendar',
            [
                'label' => esc_html__('Ali Google Calendar', 'ali'),
                'condition' => [
                    'submit_actions' => $this->get_name(),
                ],
            ]
        );

        $widget->add_control(
            'ali_gg_calendar_enable',
            [
                'label' => __('Enable', 'ali'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => '',
                'label_on' => 'Yes',
                'label_off' => 'No',
                'return_value' => 'yes',
            ]
        );

        $widget->add_control(
            'ali_gg_calendar_id',
            [
                'label' => __( 'Calendar ID* (Required)', 'pafe' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => $cld_array,
                'condition' => [
                    'ali_gg_calendar_enable' => 'yes'
                ]
            ]
        );

        $widget->add_control(
            'google_calendar_summary',
            [
                'label'        => __('Summary* (Required)', 'ali' ),
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'description' => __( 'Reload if the field id list are not shown.', 'ali' ),
                'get_fields' => true,
                'condition' => [
                    'ali_gg_calendar_enable' => 'yes'
                ]
            ]
        );

        $widget->add_control(
            'google_calendar_date_type',
            [
                'label' => __('Date Type', 'ali' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'description' => __( 'Reload if the field id list are not shown.', 'ali' ),
                'options' => [
                    'date' => __( 'Date', 'ali' ),
                    'date_time'   => __( 'Date Time', 'ali' ),
                ],
                'default' => 'date',
                'condition' => [
                    'ali_gg_calendar_enable' => 'yes'
                ]
            ]
        );

        $widget->add_control(
            'google_calendar_date_start',
            [
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,
                'label'        => __('Date Start* (Required)', 'ali' ),
                'description' => __( 'Reload if the field id list are not shown.', 'ali' ),
                'label_block'  => true,
                'condition' => [
                    'ali_gg_calendar_enable' => 'yes'
                ]
            ]
        );
        $widget->add_control(
            'google_calendar_date_end',
            [
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,
                'label'        => __('Date End* (Required)', 'ali' ),
                'description' => __( 'Reload if the field id list are not shown.', 'ali' ),
                'label_block'  => true,
                'condition' => [
                    'ali_gg_calendar_enable' => 'yes'
                ]
            ]
        );

        $widget->add_control(
            'google_calendar_time_start',
            [
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,
                'label'        => __('Time Start* (Required)', 'ali' ),
                'description' => __( 'Reload if the field id list are not shown.', 'ali' ),
                'label_block'  => true,
                'condition' => [
                    'ali_gg_calendar_enable' => 'yes',
                    'google_calendar_date_type' => 'date_time',
                ]
            ]
        );
        $widget->add_control(
            'google_calendar_time_end',
            [
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,
                'label'        => __('Time End* (Required)', 'ali' ),
                'description' => __( 'Reload if the field id list are not shown.', 'ali' ),
                'label_block'  => true,
                'condition' => [
                    'ali_gg_calendar_enable' => 'yes',
                    'google_calendar_date_type' => 'date_time',
                ]
            ]
        );

        $widget->add_control(
            'google_calendar_duration',
            [
                'type' => \Elementor\Controls_Manager::TEXT,
                'label'        => 'Duration* (Required)',
                'label_block'  => true,
                'placeholder' => '',
                'description' => __('The unit is minute. Eg:30,60,90,...Use this option if you do not have the Date End', 'ali' ),
                'condition' => [
                    'ali_gg_calendar_enable' => 'yes',
                    'google_calendar_date_type' => 'date_time',
                    'google_calendar_date_end' => ''
                ]
            ]
        );

        $widget->add_control(
            'google_calendar_attendees_name',
            [
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,
                'label'        => __('Attendees Name* (Required)', 'ali' ),
                'description' => __( 'Reload if the field id list are not shown.', 'ali' ),
                'label_block'  => true,
                'condition' => [
                    'ali_gg_calendar_enable' => 'yes'
                ]
            ]
        );

        $widget->add_control(
            'google_calendar_attendees_email',
            [
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,
                'label'        => __('Attendees Email* (Required)', 'ali' ),
                'description' => __( 'Reload if the field id list are not shown.', 'ali' ),
                'label_block'  => true,
                'condition' => [
                    'ali_gg_calendar_enable' => 'yes'
                ]
            ]
        );

        $widget->add_control(
            'google_calendar_description',
            [
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,
                'label'        => __('Description', 'ali' ),
                'description' => __( 'Reload if the field id list are not shown.', 'ali' ),
                'label_block'  => true,
                'condition' => [
                    'ali_gg_calendar_enable' => 'yes'
                ]
            ]
        );

        $widget->add_control(
            'google_calendar_location',
            [
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,
                'label'        => __('Location', 'ali' ),
                'description' => __( 'Reload if the field id list are not shown.', 'ali' ),
                'label_block'  => true,
                'condition' => [
                    'ali_gg_calendar_enable' => 'yes'
                ]
            ]
        );

        $widget->add_control(
            'google_calendar_remind_method',
            [
                'type' => \Elementor\Controls_Manager::SELECT,
                'label'        => __('Remind Method* (Required)', 'ali' ),
                'label_block'  => true,
                'value'        => 'left',
                'options'      => [
                    'email'   => __( 'Email', 'ali' ),
                    'popup' => __( 'Popup', 'ali' ),
                ],
                'condition' => [
                    'ali_gg_calendar_enable' => 'yes'
                ]
            ]
        );
        $widget->add_control(
            'google_calendar_remind_time',
            [
                'type'         => \Elementor\Controls_Manager::TEXT,
                'label'        => __('Remind Time* (Required)', 'ali' ),
                'label_block'  => true,
                'description' => __( 'The unit is minute. Eg:30,60,90,...', 'ali' ),
                'condition' => [
                    'ali_gg_calendar_enable' => 'yes'
                ]
            ]
        );

        $widget->end_controls_section();

    }


    public function run($record, $ajax_handler) {

        $settings = $record->get('form_settings');
        $raw_fields = $record->get('fields');
        $fields = [];

        foreach ($raw_fields as $id => $field) {
            $fields[$id] = $field['value'];

        }
        $gg_calendar_date_end = $fields[$settings['google_calendar_date_end']];
        $gg_calendar_date_start = $fields[$settings['google_calendar_date_start']];
        $gg_calendar_client_secret = get_option('ali-google-calendar-client-secret');
        $gg_calendar_client_id = get_option('ali-google-calendar-client-id');
        $gg_calendar_rtok = get_option('ali-google-calendar-refresh-token');
        $gg_calendar_api = get_option('ali-google-calendar-client-api-key');
        $gg_calendar_id = $settings['ali_gg_calendar_id'];

        $data_gg_calendar = [
            'summary' => $settings['google_calendar_summary'] ,
            'location' => $fields[$settings['google_calendar_location']],
            'description' => $fields[$settings['google_calendar_description']],
        ];

        $attendees_email = $fields[$settings['google_calendar_attendees_email']];
        if ( !empty($attendees_email) ) {
            $data_gg_calendar['attendees'] = [
                [
                    'displayName' => $fields[$settings['google_calendar_attendees_name']],
                    'email' => $attendees_email,
                ]
            ];
        }

        $remind_time = $settings['google_calendar_remind_time'];
        $remind_method = $settings['google_calendar_remind_method'];

        if ( !empty($remind_time) && !empty($remind_method) ) {
            $remind_time = (int)$remind_time;
            $data_gg_calendar['reminders'] = [
                'useDefault' => false,
                'overrides' => [
                    [
                        'method' => $remind_method,
                        'minutes' => $remind_time,
                    ],
                ],
            ];
        } else if ( $remind_time == 0 ){
            $data_gg_calendar['reminders'] = [
                'useDefault' => false,
                'overrides' => [
                    [
                        'method' => $remind_method,
                        'minutes' => 0,
                    ],
                ],
            ];
        } else if ( empty($remind_time) ){
            $data_gg_calendar['reminders'] = [
                'useDefault' => false,
                'overrides' => [
                    [
                        'method' => $remind_method,
                        'minutes' => 60,
                    ],
                ],
            ];
        }

        $google_calendar_date_type = $settings['google_calendar_date_type'];
        if ( $google_calendar_date_type == 'date_time') {
            $data_gg_calendar['start'] = [
                'dateTime' => $gg_calendar_date_start,
            ];

            $gg_calendar_formatted_date_end = null;
            if (empty($gg_calendar_date_end)) {
                $seconds_duration = (int)$settings['google_calendar_duration'] * 60;
                $gg_calendar_formatted_date_end = date("c",strtotime($gg_calendar_date_start) + $seconds_duration);
            } else {
                $gg_calendar_formatted_date_end = $gg_calendar_date_end;
            }
            $data_gg_calendar['end'] = [
                'dateTime' => $gg_calendar_formatted_date_end,
            ];
        } else if ( $google_calendar_date_type == 'date') {
            $gg_calendar_formatted_date_start = date('Y-m-d',strtotime($gg_calendar_date_start));

            $gg_calendar_formatted_date_end = empty($gg_calendar_date_end) ? $gg_calendar_formatted_date_start : date('Y-m-d',strtotime($gg_calendar_date_end));
            $data_gg_calendar['end'] = [
                'date' => $gg_calendar_formatted_date_end,
            ];
            $data_gg_calendar['start'] = [
                'date' => $gg_calendar_formatted_date_start,
            ];
        }

        // Refresh Token
        $google_calendar_expired_token = get_option('ali-google-calendar-expired-token');
        $google_calendar_expired_token = (int)$google_calendar_expired_token;
        $google_calendar_current_time = time();

        if ($google_calendar_expired_token < $google_calendar_current_time) {
            $google_calendar_request_token = [
                'body' => [],
                'headers' => array(
                    'Content-type' => 'application/x-www-form-urlencoded',
                ),
            ];

            $google_calendar_refresh_token = wp_remote_post( 'https://www.googleapis.com/oauth2/v4/token?client_id=' . $gg_calendar_client_id . '&client_secret=' . $gg_calendar_client_secret . '&refresh_token=' . $gg_calendar_rtok . '&grant_type=refresh_token', $google_calendar_request_token );
            $google_calendar_refresh_token = json_decode( wp_remote_retrieve_body( $google_calendar_refresh_token) );

            if (!empty($google_calendar_refresh_token->access_token)) {
                $gg_calendar_atok = $google_calendar_refresh_token->access_token;
                $gg_cld_newexpired = get_option('ali-google-calendar-expires');
                $gg_cld_newexpired = (int)$gg_cld_newexpired;
                update_option( 'ali-google-calendar-access-token', $gg_calendar_atok );
                $google_calendar_new_expired_token = time() + $gg_cld_newexpired;
                update_option( 'ali-google-calendar-expired-token', $google_calendar_new_expired_token );
            }
        }

        $gg_calendar_access_token = get_option('ali-google-calendar-access-token');
        $gg_cld_data = array(
            'headers'     => array(
                "Authorization"=>" Bearer ".$gg_calendar_access_token,
                "Accept" => "application/json",
                "Content-Type" => "application/json"
            ),
            'body' => json_encode($data_gg_calendar)
        );
        wp_remote_post("https://www.googleapis.com/calendar/v3/calendars/$gg_calendar_id/events?key=$gg_calendar_api", $gg_cld_data);

    }

    public function on_export($element)
    {

        return $element;

    }

}