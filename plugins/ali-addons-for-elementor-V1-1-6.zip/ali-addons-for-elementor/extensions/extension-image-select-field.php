<?php
require_once( __DIR__ . '/ali-custom-tab.php' );

class Ali_Image_Select_Field extends \Elementor\Widget_Base {

    public function __construct() {
        parent::__construct();
        $this->init_control();
    }

    public function get_name() {
        return 'ali-image-select-field';
    }

    public function ali_register_script() {
        wp_register_script( 'ali-image-select-field-script', plugins_url('assets/js/minify/ali-image-select-field.min.js', dirname( __FILE__ ) ), [ 'jquery' ], ALI_ADDONS_FOR_ELEMENTOR_VERSION );
        wp_enqueue_script( 'ali-image-select-field-script');

        wp_register_style( 'ali-image-select-field-style', plugins_url('assets/css/minify/ali-image-select.min.css', dirname( __FILE__ ) ), [], ALI_ADDONS_FOR_ELEMENTOR_VERSION );
        wp_enqueue_style( 'ali-image-select-field-style' );
    }

    public function ali_register_controls( $element, $args ) {

        $element->start_controls_section(
            'ali_image_select_field_section',
            [
                'label' => __( 'Ali Image Picker Field', 'ali' ),
                'tab' => Ali_Controls_Manager::TAB_ALI,
            ]
        );

        $element->add_control(
            'ali_image_select_field_enable',
            [
                'label' => __( 'Enable', 'ali' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => '',
                'description' => __( 'This feature only works on the frontend.', 'ali' ),
                'label_on' => 'Yes',
                'label_off' => 'No',
                'return_value' => 'yes',
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'ali_image_select_field_id',
            [
                'label' => __( 'Image Picker Field Custom ID', 'ali' ),
                'label_block' => true,
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,
                'description' => __( 'Reload if the field id list are not shown.', 'ali' ),
            ]
        );

        $repeater->add_control(
            'ali_image_select_field_gallery',
            [
                'label' => __( 'Add Images', 'ali' ),
                'type' => \Elementor\Controls_Manager::GALLERY,
                'default' => [],
            ]
        );

        $element->add_control(
            'ali_image_select_field_list',
            array(
                'type'    => Elementor\Controls_Manager::REPEATER,
                'fields'  => $repeater->get_controls(),
                'condition' => [
                    'ali_image_select_field_enable' => 'yes',
                ],
            )
        );

        $element->end_controls_section();
        $element->start_controls_section(
            'ali_image_select_field_style_section',
            [
                'label' => __( 'Ali Image Picker Style', 'ali' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ali_image_select_field_enable' => 'yes',
                ],
            ]
        );
        $element->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'ali_image_select_field_typography',
                'label' => __( 'Typography', 'ali' ),
                'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .image_picker_selector .thumbnail p',
                'condition' => [
                    'ali_image_select_field_enable' => 'yes',
                ],
            ]
        );

        $element->add_responsive_control(
            'ali_image_select_field_text_align',
            [
                'label' => __( 'Text Align', 'ali' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'elementor' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'elementor' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'elementor' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .image_picker_selector .thumbnail p' => 'text-align: {{VALUE}};',
                ],
                'condition' => [
                    'ali_image_select_field_enable' => 'yes',
                ],
            ]
        );

        $element->add_responsive_control(
            'ali_image_select_field_item_width',
            [
                'label' => __( 'Item Width (%)', 'ali' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 25,
                'min' => 1,
                'max' => 100,
                'selectors' => [
                    '{{WRAPPER}} ul.thumbnails.image_picker_selector li' => 'width: {{VALUE}}% !important;',
                ],
                'condition' => [
                    'ali_image_select_field_enable' => 'yes',
                ],
            ]
        );

        $element->add_responsive_control(
            'ali_image_select_field_item_spacing',
            [
                'label' => __( 'Spacing', 'ali' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} ul.thumbnails.image_picker_selector li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'ali_image_select_field_enable' => 'yes',
                ],
            ]
        );

        $element->add_responsive_control(
            'ali_image_select_field_item_border_radius',
            [
                'label' => __( 'Item Border Radius', 'ali' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} ul.thumbnails.image_picker_selector .thumbnail' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'ali_image_select_field_enable' => 'yes',
                ],
            ]
        );

        $element->add_responsive_control(
            'ali_image_select_field_image_padding',
            [
                'label' => __( 'Image Padding', 'ali' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .image_picker_image' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'ali_image_select_field_enable' => 'yes',
                ],
            ]
        );

        $element->add_responsive_control(
            'ali_image_select_field_label_padding',
            [
                'label' => __( 'Title Padding', 'ali' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} ul.thumbnails p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'ali_image_select_field_enable' => 'yes',
                ],
            ]
        );

        $element->start_controls_tabs('ali_image_select_field_normal_active');

        $element->start_controls_tab(
            'ali_image_select_field_normal',
            [
                'label' => __( 'Normal', 'elementor' ),
                'condition' => [
                    'ali_image_select_field_enable' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ali_image_select_field_border_normal',
            [
                'label' => __( 'Item Border Type', 'ali' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '' => __( 'None', 'elementor' ),
                    'solid' => _x( 'Solid', 'Border Control', 'elementor' ),
                    'double' => _x( 'Double', 'Border Control', 'elementor' ),
                    'dotted' => _x( 'Dotted', 'Border Control', 'elementor' ),
                    'dashed' => _x( 'Dashed', 'Border Control', 'elementor' ),
                    'groove' => _x( 'Groove', 'Border Control', 'elementor' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} ul.thumbnails.image_picker_selector .thumbnail' => 'border-style: {{VALUE}};',
                ],
                'condition' => [
                    'ali_image_select_field_enable' => 'yes',
                ],
            ]
        );

        $element->add_responsive_control(
            'ali_image_select_field_border_width_normal',
            [
                'label' => __( 'Item Border Width', 'ali' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} ul.thumbnails.image_picker_selector .thumbnail' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'ali_image_select_field_border_normal!' => '',
                    'ali_image_select_field_enable' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ali_image_select_field_border_color_normal',
            [
                'label' => __( 'Item Border Color', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} ul.thumbnails.image_picker_selector .thumbnail' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    'ali_image_select_field_border_normal!' => '',
                    'ali_image_select_field_enable' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ali_image_select_field_background_color_normal',
            [
                'label' => __( 'Background Color', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} ul.thumbnails.image_picker_selector .thumbnail' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'ali_image_select_field_enable' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ali_image_select_field_text_color_normal',
            [
                'label' => __( 'Text Color', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} ul.thumbnails.image_picker_selector .thumbnail p' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'ali_image_select_field_enable' => 'yes',
                ],
            ]
        );

        $element->end_controls_tab();

        $element->start_controls_tab(
            'ali_image_select_field_active',
            [
                'label' => __( 'Active', 'elementor' ),
                'condition' => [
                    'ali_image_select_field_enable' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ali_image_select_field_border_active',
            [
                'label' => __( 'Item Border Type', 'ali' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '' => __( 'None', 'elementor' ),
                    'solid' => _x( 'Solid', 'Border Control', 'elementor' ),
                    'double' => _x( 'Double', 'Border Control', 'elementor' ),
                    'dotted' => _x( 'Dotted', 'Border Control', 'elementor' ),
                    'dashed' => _x( 'Dashed', 'Border Control', 'elementor' ),
                    'groove' => _x( 'Groove', 'Border Control', 'elementor' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} ul.thumbnails.image_picker_selector .thumbnail.selected' => 'border-style: {{VALUE}};',
                ],
                'condition' => [
                    'ali_image_select_field_enable' => 'yes',
                ],
            ]
        );

        $element->add_responsive_control(
            'ali_image_select_field_border_width_active',
            [
                'label' => __( 'Item Border Width', 'ali' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} ul.thumbnails.image_picker_selector .thumbnail.selected' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'ali_image_select_field_border_active!' => '',
                    'ali_image_select_field_enable' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ali_image_select_field_border_color_active',
            [
                'label' => __( 'Item Border Color', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} ul.thumbnails.image_picker_selector .thumbnail.selected' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    'ali_image_select_field_border_active!' => '',
                ],
            ]
        );

        $element->add_control(
            'ali_image_select_field_background_color_active',
            [
                'label' => __( 'Background Color', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} ul.thumbnails.image_picker_selector .thumbnail.selected' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $element->add_control(
            'ali_image_select_field_text_color_active',
            [
                'label' => __( 'Text Color', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} ul.thumbnails.image_picker_selector .thumbnail.selected p' => 'color: {{VALUE}};',
                ],
            ]
        );

        $element->end_controls_tab();
        $element->end_controls_tabs();
        $element->end_controls_section();

    }

    public function before_render_element($element) {
        $settings = $element->get_settings();
        if (!empty($settings['ali_image_select_field_enable'])) {
            if ( array_key_exists( 'ali_image_select_field_list',$settings ) ) {
                $list = $settings['ali_image_select_field_list'];
                if( !empty($list[0]['ali_image_select_field_id']) && !empty($list[0]['ali_image_select_field_gallery']) ) {

                    $element->add_render_attribute( '_wrapper', [
                        'data-ali-image-select-field' => json_encode($list),
                    ] );
                }
            }
        }
    }

    public function before_content($element) {
        $settings = $element->get_settings_for_display();

        if ( isset($settings['ali_image_select_field_enable']) && $settings['ali_image_select_field_enable'] === 'yes' ) {
            add_action( 'elementor/frontend/before_enqueue_scripts', [$this, 'ali_register_script'] );
        }
    }

    protected function init_control() {
        add_action( 'elementor/element/form/section_form_fields/after_section_end', [ $this, 'ali_register_controls' ], 10, 2 );
        add_action( 'elementor/frontend/widget/before_render', [ $this, 'before_render_element'], 10, 1 );
        add_action( 'elementor/widget/before_render_content', [$this, 'before_content'] );
    }

}
