<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Ali_Google_Sheet extends \ElementorPro\Modules\Forms\Classes\Action_Base{

    public function get_name()
    {
        return 'gs';
    }

    public function get_label()
    {
        return esc_html__('Ali Google Sheet', 'ali');
    }

    public function register_settings_section($widget)
    {

        $widget->start_controls_section(
            'section_ali_gs',
            [
                'label' => esc_html__('Ali Google Sheet', 'ali'),
                'condition' => [
                    'submit_actions' => $this->get_name(),
                ],
            ]
        );

        $widget->add_control(
            'ali_gs_enable',
            [
                'label' => __('Enable', 'ali'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => '',
                'label_on' => 'Yes',
                'label_off' => 'No',
                'return_value' => 'yes',
            ]
        );

        $widget->add_control(
            'ali_gs_id',
            [
                'label' => __('Google Sheet ID', 'ali'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'ali_gs_enable' => 'yes',
                ],
            ]
        );

        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'ali_gs_column',
            [
                'label' => __('Column', 'ali'),
                'label_block' => true,
                'type' => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $repeater->add_control(
            'ali_gs_field_id',
            [
                'label' => __('Field ID', 'ali'),
                'label_block' => true,
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,
                'description' => __( 'Reload if the field id list are not shown.', 'ali' ),
            ]
        );

        $widget->add_control(
            'ali_gs_property_list',
            [
                'type' => Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ali_gs_column}}}',
                'label' => __('Property', 'ali'),
                'condition' => [
                    'ali_gs_enable' => 'yes',
                ],
            ]
        );

        $widget->end_controls_section();

    }

    static function getIndexColumn($column){
        $columnArray = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');
        $columnFirstWord = strtoupper(substr($column, 0, 1));
        $columnSecondWord = strtoupper(substr($column, 1, 2));
        $index = 0;

        if ($columnSecondWord == '') {
            $index = array_search($columnFirstWord, $columnArray);
        } else {
            $index = (array_search($columnFirstWord, $columnArray) + 1) * 26 + array_search($columnSecondWord, $columnArray);
        }

        return $index;
    }

    public function run($record, $ajax_handler) {

        $settings = $record->get('form_settings');
        $raw_fields = $record->get('fields');
        $fields = [];

        foreach ($raw_fields as $id => $field) {
            $fields[$id] = $field['value'];
        }

        $row = array();
        $fieldList = $settings['ali_gs_property_list'];
        $fieldColumns = array();
        for ($i = 0; $i < count($fieldList); $i++) {
            $fieldColumns[] = $this->getIndexColumn($fieldList[$i]['ali_gs_column']);
        }
        for ($z = 0; $z < (max($fieldColumns) + 1); $z++) {
            $value = '';
            for ($i = 0; $i < count($fieldList); $i++) {
                $field_column = $fieldList[$i]['ali_gs_column'];
                if ($z == $this->getIndexColumn($field_column)) {
                    for ($j = 0; $j < count($fieldList); $j++) {
                        $value = $fields[$fieldList[$i]['ali_gs_field_id']];
                        $value = str_replace("<br />", "\n", $value);
                        $value = str_replace("<br/>", "\n", $value);
                        $value = str_replace("<br>", "\n", $value);
                        $value = str_replace("<strong>", "", $value);
                        $value = str_replace("</strong>", "", $value);
                        $value = strip_tags($value);
                    }
                }
            }

            $row[] = !str_contains($value, '[field id="') ? $value : '';
        }
        // Config
        $gs_sheet_id = $settings['ali_gs_id'];
        $gs_tab = !empty($form['settings']['ali_form_gss_connector_tab']) ? $form['settings']['ali_form_gss_connector_tab'] . '!' : '';
        $gs_client_id = get_option('ali-gs-client-id');
        $gs_client_secret = get_option('ali-gs-client-secret');
        $gs_refresh_token = get_option('ali-gs-refresh-token');
        $gs_url = 'https://sheets.googleapis.com/v4/spreadsheets/' . $gs_sheet_id . '/values/'  . 'A1:append?includeValuesInResponse=false&insertDataOption=INSERT_ROWS&responseDateTimeRenderOption=SERIAL_NUMBER&responseValueRenderOption=FORMATTED_VALUE&valueInputOption=USER_ENTERED';
        $gs_body = array(
            "majorDimension" => "ROWS",
            "values" => array($row),
        );
        $gs_body = json_encode($gs_body);

        // HTTP Request Token Refresh
        $gs_expired_token = get_option('ali-gs-expired-token');
        $gs_expired_token = (int)$gs_expired_token;
        $gs_current_time = time();

        if ($gs_expired_token < $gs_current_time) {
            $gs_get_ac_second = [
                'body' => [],
                'headers' => array(
                    'Content-type' => 'application/x-www-form-urlencoded',
                ),
            ];

            $gs_request_get_ac_token = wp_remote_post('https://www.googleapis.com/oauth2/v4/token?client_id=' . $gs_client_id . '&client_secret=' . $gs_client_secret . '&refresh_token=' . $gs_refresh_token . '&grant_type=refresh_token', $gs_get_ac_second);
            $gs_new_token = json_decode(wp_remote_retrieve_body($gs_request_get_ac_token));

            if (!empty($gs_new_token->access_token)) {
                $gs_access_token = $gs_new_token->access_token;
                $gs_new_expired = get_option('ali-gs-expires');
                $gs_new_expired = (int)$gs_new_expired;

                $gs_new_expired_time = time() + $gs_new_expired;

                update_option('ali-gs-access-token', $gs_access_token);
                update_option('ali-gs-expired-token', $gs_new_expired_time);
            }
        }
        $gs_access_token = get_option('ali-gs-access-token');
        $gs_send_data = [
            'headers' => array(
                'Content-type' => 'application/json',
                'Authorization' => 'Bearer ' . $gs_access_token,
                'Accept'=>  'application/json'
            ),
            'body' => $gs_body,
        ];
        wp_remote_post($gs_url, $gs_send_data);

    }

    public function on_export($element)
    {

        return $element;

    }

}