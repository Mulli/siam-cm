<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Ali_Term_Field extends \ElementorPro\Modules\Forms\Fields\Field_Base
{

    public function __construct()
    {
        parent::__construct();

        add_action('elementor/preview/init', [$this, 'editor_preview_footer']);
        add_action( 'elementor-pro/forms/pre_render', [$this, 'before_content'] );
        add_action('elementor/element/form/section_form_fields/before_section_end', [$this, 'ali_custom_field_control'], 100, 2);
    }

    public function get_type()
    {
        return 'ali-term-field';
    }

    public function get_name()
    {
        return esc_html__('Ali Term Field', 'ali');
    }

    public function ali_custom_field_control($element, $args)
    {
        $post_types = get_post_types( [], 'objects' );
        $taxonomies = [];

        foreach ( $post_types as $post_type ) {
            $taxonomies_of_post_type = get_object_taxonomies( $post_type->name, 'objects' );
            foreach ($taxonomies_of_post_type as $taxonomy) {

                $taxonomies[$taxonomy->name] = $taxonomy->label . ' (' . $post_type->name . ')';
            }
        }
        $elementor = \Elementor\Plugin::instance();
        $control_data = $elementor->controls_manager->get_control_from_stack($element->get_name(), 'form_fields');

        if (is_wp_error($control_data)) {
            return;
        }
        $field_new_controls = [
            'ali_term_field' => [
                'name' => 'ali_term_field',
                'label' => __('Taxonomy Slug', 'ali'),
                'label_block' => true,
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => $taxonomies,
                'condition' => [
                    'field_type' => $this->get_type(),
                ],
                'tab' => 'content',
                'inner_tab' => 'form_fields_content_tab',
                'tabs_wrapper' => 'form_fields_tabs',
            ],
        ];

        $field_control_data['fields'] = $control_data['fields'] + $field_new_controls;
        $element->update_control('form_fields', $field_control_data);
    }

    public function before_content($element){
        add_action( 'elementor/frontend/before_enqueue_scripts', [$this, 'ali_register_script'] );
    }

    public function ali_register_script() {

        wp_register_style( 'ali-term-field-style', plugins_url('assets/css/minify/ali-term-field.min.css', dirname( __FILE__ ) ), [], ALI_ADDONS_FOR_ELEMENTOR_VERSION );
        wp_enqueue_style( 'ali-term-field-style' );
    }


    public function render($item, $i, $form)
    {
        $settings = $form->get_settings_for_display();
        $options_html = "";
        $form->add_render_attribute(
            [
                'select-wrapper' . $i => [
                    'class' => [
                        'elementor-field',
                        'elementor-select-wrapper',
                        'ali-term-field',
                        esc_attr($item['css_classes']),
                    ],
                ],
                'select' . $i => [
                    'name' => $form->get_attribute_name($item) . (!empty($item['allow_multiple']) ? '[]' : ''),
                    'id' => $form->get_attribute_id($item),
                    'class' => [
                        'elementor-field-textual',
                        'elementor-size-' . $item['input_size'],
                    ],
                ],
            ]
        );

        if (!empty($item['ali_term_field'])) {
            $terms = get_terms(array(
                'taxonomy' => $item['ali_term_field'],
                'hide_empty' => false,
            ));
            if (!empty($terms) && !is_wp_error($terms)) {
                foreach ($terms as $term) {
                    $options_html .= '<option value="'.$term->slug.'">' . $term->name . '</option>';
                }
            }
        }

        ?>
        <div <?php echo $form->get_render_attribute_string('select-wrapper' . $i); ?>>
            <select <?php echo $form->get_render_attribute_string('select' . $i); ?>><?php echo $options_html; ?></select>
        </div>
        <?php
    }

    public function validation($field, $record, $ajax_handler)
    {
        if (empty($field['value'])) {
            return;
        }
    }

    public function editor_preview_footer()
    {
        add_action('wp_footer', [$this, 'content_template_script']);
    }

    public function content_template_script()
    {

    }

}
