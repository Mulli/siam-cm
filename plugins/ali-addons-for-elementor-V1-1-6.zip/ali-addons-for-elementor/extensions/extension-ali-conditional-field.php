<?php

class Ali_Conditional_Logic_Form extends \Elementor\Widget_Base {

    public function __construct() {
        parent::__construct();
        $this->init_control();
    }

    public function get_name() {
        return 'ali-conditional-logic-form';
    }

    public function before_content($element) {
        $settings = $element->get_settings_for_display();
        if ( isset($settings['ali_conditional_logic_form_enable']) && $settings['ali_conditional_logic_form_enable'] === 'yes' ) {
            add_action( 'elementor/frontend/before_enqueue_scripts', [$this, 'ali_register_script'] );
        }
    }

    public function ali_register_script() {
        wp_register_script( 'ali-conditional-for-field-script', plugins_url('assets/js/minify/ali-conditional-for-field.min.js', dirname( __FILE__ ) ), [ 'jquery' ], ALI_ADDONS_FOR_ELEMENTOR_VERSION );
        wp_enqueue_script( 'ali-conditional-for-field-script');

    }


    public function ali_register_controls( $element, $args ) {

        $element->start_controls_section(
            'ali_conditional_logic_form_section',
            [
                'label' => __( 'Ali Conditional Logic Form', 'ali' ),
                'tab' => Ali_Controls_Manager::TAB_ALI,
            ]
        );

        $element->add_control(
            'ali_conditional_logic_form_enable',
            [
                'label' => __( 'Enable', 'ali' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => '',
                'description' => __( 'This feature only works on the frontend.', 'ali' ),
                'label_on' => 'Yes',
                'label_off' => 'No',
                'return_value' => 'yes',
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'ali_conditional_logic_form_show',
            [
                'label' => __( 'Show', 'ali' ),
                'description' => __( 'Reload if the field id list are not shown.', 'ali' ),
                'label_block' => true,
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,
            ]
        );

        $repeater->add_control(
            'ali_conditional_logic_form_if',
            [
                'label' => __( 'If', 'ali' ),
                'description' => __( 'Reload if the field id list are not shown.', 'ali' ),
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,
                'label_block' => true,

            ]
        );

        $repeater->add_control(
            'ali_conditional_logic_form_comparison_operators',
            [
                'label' => __( 'Comparison Operators', 'ali' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'label_block' => true,
                'options' => [
                    'not-empty' => __( 'not empty', 'ali' ),
                    'empty' => __( 'empty', 'ali' ),
                    '=' => __( 'equals', 'ali' ),
                    '!=' => __( 'not equals', 'ali' ),
                    '>' => __( '>', 'ali' ),
                    '>=' => __( '>=', 'ali' ),
                    '<' => __( '<', 'ali' ),
                    '<=' => __( '<=', 'ali' ),
                    'checked' => __( 'checked', 'ali' ),
                    'unchecked' => __( 'unchecked', 'ali' ),
                ],
            ]
        );

        $repeater->add_control(
            'ali_conditional_logic_form_type',
            [
                'label' => __( 'Type Value', 'ali' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'label_block' => true,
                'options' => [
                    'string' => __( 'String', 'ali' ),
                    'number' => __( 'Number', 'ali' ),
                ],
                'default' => 'string',
                'condition' => [
                    'ali_conditional_logic_form_comparison_operators' => ['=','!=','>','>=','<','<='],
                ],
            ]
        );

        $repeater->add_control(
            'ali_conditional_logic_form_value',
            [
                'label' => __( 'Value', 'ali' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'placeholder' => __( '50', 'ali' ),
                'condition' => [
                    'ali_conditional_logic_form_comparison_operators' => ['=','!=','>','>=','<','<='],
                ],
            ]
        );

        $repeater->add_control(
            'ali_conditional_logic_form_and_or_operators',
            [
                'label' => __( 'OR, AND Operators', 'ali' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'label_block' => true,
                'options' => [
                    'or' => __( 'OR', 'ali' ),
                    'and' => __( 'AND', 'ali' ),
                ],
                'default' => 'or',
            ]
        );

        $element->add_control(
            'ali_conditional_logic_form_list',
            [
                'type'    => Elementor\Controls_Manager::REPEATER,
                'fields'  => $repeater->get_controls(),
                'title_field' => 'Conditional for {{{ ali_conditional_logic_form_show }}}',
                'condition' => [
                    'ali_conditional_logic_form_enable' => 'yes',
                ]
            ]
        );

        $element->end_controls_section();
    }

    public function before_render_element($element) {
        $settings = $element->get_settings();
        if (!empty($settings['ali_conditional_logic_form_enable'])) {
            if ( array_key_exists( 'ali_conditional_logic_form_list',$settings ) ) {
                $list = $settings['ali_conditional_logic_form_list'];
                if( !empty($list[0]['ali_conditional_logic_form_show']) && !empty($list[0]['ali_conditional_logic_form_if']) && !empty($list[0]['ali_conditional_logic_form_comparison_operators']) ) {

                    $element->add_render_attribute( '_wrapper', [
                        'data-ali-conditional-logic-form' => json_encode($list),
                        'data-ali-conditional-logic-form-speed' => $settings['ali_conditional_logic_form_speed'],
                        'data-ali-conditional-logic-form-easing' => $settings['ali_conditional_logic_form_easing'],
                    ] );

                    if (!empty($settings['mark_required'])) {
                        $element->add_render_attribute( '_wrapper', [
                            'data-ali-conditional-logic-form-mark-required' => '',
                        ] );
                    }
                }
            }
        }
    }

    protected function init_control() {
        add_action( 'elementor/element/form/section_form_fields/after_section_end', [ $this, 'ali_register_controls' ], 10, 2 );
        add_action( 'elementor/frontend/widget/before_render', [ $this, 'before_render_element'], 10, 1 );
        add_action( 'elementor/widget/before_render_content', [$this, 'before_content'] );

    }

}
