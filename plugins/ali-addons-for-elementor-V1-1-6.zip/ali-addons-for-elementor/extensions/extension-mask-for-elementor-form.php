<?php
require_once( __DIR__ . '/ali-custom-tab.php' );

class Ali_Mask_For_Elementor_Form extends \Elementor\Widget_Base {

    public function __construct() {
        parent::__construct();
        $this->init_control();
    }

    public function get_name() {
        return 'ali-mask-for-elementor-form';
    }


    public function ali_register_script() {
        wp_register_script( 'ali-mask-for-field-script', plugins_url('assets/js/minify/ali-mask-for-field.min.js', dirname( __FILE__ ) ), [ 'jquery' ], ALI_ADDONS_FOR_ELEMENTOR_VERSION );
        wp_enqueue_script( 'ali-mask-for-field-script');
    }
    
    public function ali_register_controls( $element, $args ) {
        
        $element->start_controls_section(
            'ali_mask_for_elementor_section',
            [
                'label' => __( 'Ali Mask For Elementor Form', 'ali' ),
                'tab' => Ali_Controls_Manager::TAB_ALI,
            ]
        );

        $element->add_control(
            'ali_mask_for_elementor_enable',
            [
                'label' => __( 'Enable', 'ali' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => 'Yes',
                'label_off' => 'No',
                'return_value' => 'yes',
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'ali_mask_for_elementor_field_custom_id',
            [
                'label' => __( 'Text Field Custom ID', 'ali' ),
                'label_block' => true,
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,
                'description' => __( 'Reload if the field id list are not shown.', 'ali' ),
            ]
        );

        $repeater->add_control(
            'ali_mask_for_elementor_format',
            [
                'label' => __( 'Mask', 'ali' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'description' => __( 'E.g (00) 0000-0000 . Documents: https://igorescobar.github.io/jQuery-Mask-Plugin/docs.html', 'ali' ),
            ]
        );

        $element->add_control(
            'ali_mask_for_elementor_field_list', array(
                'type'    => Elementor\Controls_Manager::REPEATER,
                'fields'  => $repeater->get_controls(),
                'condition' => [
                    'ali_mask_for_elementor_enable' => 'yes',
                ],
            )
        );

        $element->end_controls_section();

    }

    public function before_render_element($element) {
        $settings = $element->get_settings();
        if (!empty($settings['ali_mask_for_elementor_enable'])) {
            if ( array_key_exists( 'ali_mask_for_elementor_field_list',$settings ) ) {
                $list = $settings['ali_mask_for_elementor_field_list'];
                if( !empty($list[0]['ali_mask_for_elementor_field_custom_id']) && !empty($list[0]['ali_mask_for_elementor_format']) ) {

                    $element->add_render_attribute( '_wrapper', [
                        'data-ali-mask-for-elementor' => json_encode($list),
                    ] );
                }
            }
        }
    }
    public function before_content($element) {
        $settings = $element->get_settings_for_display();
        if ( isset($settings['ali_mask_for_elementor_enable']) && $settings['ali_mask_for_elementor_enable'] === 'yes' ) {
            add_action( 'elementor/frontend/before_enqueue_scripts', [$this, 'ali_register_script'] );
        }
    }

    protected function init_control() {
        add_action( 'elementor/element/form/section_form_fields/after_section_end', [ $this, 'ali_register_controls' ], 10, 2 );
        add_action( 'elementor/frontend/widget/before_render', [ $this, 'before_render_element'], 10, 1 );
        add_action( 'elementor/widget/before_render_content', [$this, 'before_content'] );
    }

}
