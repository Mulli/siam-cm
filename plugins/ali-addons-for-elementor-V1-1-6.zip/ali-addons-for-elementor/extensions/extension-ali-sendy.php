<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

class Ali_Sendy extends \ElementorPro\Modules\Forms\Classes\Action_Base {

    public function get_name() {
        return 'sendy';
    }

    public function get_label() {
        return esc_html__( 'Ali Sendy', 'ali' );
    }

    public function register_settings_section( $widget ) {

        $widget->start_controls_section(
            'section_ali_sendy',
            [
                'label' => esc_html__( 'Ali Sendy ', 'ali' ),
                'condition' => [
                    'submit_actions' => $this->get_name(),
                ],
            ]
        );

        $widget->add_control(
            'ali_sendy_enable',
            [
                'label' => __( 'Enable', 'ali' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => '',
                'label_on' => 'Yes',
                'label_off' => 'No',
                'return_value' => 'yes',
            ]
        );

        $widget->add_control(
            'sendy_url',
            [
                'label' => __( 'Sendy URL', 'ali' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => 'http://your_sendy_installation/',
                'label_block' => true,
                'separator' => 'before',
                'description' => __( 'Enter the URL where you have Sendy installed, including a trailing /', 'ali' ),
            ]
        );
        $widget->add_control(
            'sendy_api_key',
            [
                'label' => __( 'API key', 'ali' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'description' => __( 'To find it go to Settings (top right corner) -> Your API Key.', 'ali' ),
            ]
        );
        $widget->add_control(
            'sendy_list_id',
            [
                'label' => __( 'Sendy List ID', 'ali' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'separator' => 'before',
                'description' => __( 'The list id you want to subscribe a user to.', 'ali' ),
            ]
        );

        $widget->add_control(
            'sendy_name_field_shortcode',
            [
                'label' => __( 'Name Field Shortcode', 'ali' ),
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,
            ]
        );

        $widget->add_control(
            'sendy_email_field_shortcode',
            [
                'label' => __( 'Email Field Shortcode', 'ali' ),
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,
            ]
        );

        $widget->add_control(
            'sendy_gdpr_shortcode',
            [
                'label' => __( 'GDPR/CCPA Compliant Shortcode', 'ali' ),
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'custom_field_name', [
                'label' => __( 'Sendy Custom Field Name', 'ali' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'description' => __( 'Place the Name of the Sendy Custom Field', 'ali' ),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'custom_field_shortcode', [
                'label' => __( 'Custom Field Shortcode', 'ali' ),
                'type' => \Elementor\AliCustomControls\Select_Control::Select,
                'get_fields' => true,
                'label_block' => true,
            ]
        );

        $widget->add_control(
            'sendy_custom_fields',
            [
                'label' => __( 'Custom Fields', 'ali' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ custom_field_name }}}',
                'separator' => 'before'
            ]
        );

        $widget->end_controls_section();

    }

    public function run( $record, $ajax_handler ) {
        $settings = $record->get( 'form_settings' );
        $raw_fields = $record->get( 'fields' );
        $fields = [];

        foreach ( $raw_fields as $id => $field ) {
            $fields[ $id ] = $field['value'];
        }

        if (!empty($settings['sendy_url']) && !empty($settings['sendy_api_key']) && !empty($settings['sendy_name_field_shortcode']) && !empty($settings['sendy_email_field_shortcode']) && !empty($settings['sendy_list_id'])) {

            $sendy_url = $settings['sendy_url'];
            $sendy_api = $settings['sendy_api_key'];
            $sendy_name = $fields['sendy_name_field_shortcode'];
            $sendy_email = $fields['sendy_email_field_shortcode'];
            $sendy_list = $settings['sendy_list_id'];
            $sendy_custom_fields = count($settings['sendy_custom_fields']);

            $gdpr = false;
            if(!empty($settings['sendy_gdpr_shortcode'])){
                $gdpr_value = $fields['sendy_gdpr_shortcode'];
                $gdpr = !empty($gdpr_value) ? 'true' : 'false';
            }

            $sendy_data = [
                'name' => $sendy_name,
                'email' => $sendy_email,
                'list' => $sendy_list,
                'gdpr' => $gdpr,
                'api_key' => $sendy_api,
                'ipaddress' => \ElementorPro\Core\Utils::get_client_ip(),
                'referrer' => isset( $_POST['referrer'] ) ? $_POST['referrer'] : '',

            ];

            for($i = 0; $i < $sendy_custom_fields; $i++){
                $custom_field_name = $settings['sendy_custom_fields'][$i]['custom_field_name'];
                $custom_field_value = $fields['sendy_custom_fields'][$i]['custom_field_shortcode'];
                $sendy_data[$custom_field_name] = $custom_field_value;
            }
        }
        $sendy = wp_remote_post( $sendy_url . '/subscribe', [
            'body' => $sendy_data,
        ] );
        //echo $sendy;
    }

    public function on_export( $element ) {

        return $element;

    }

}