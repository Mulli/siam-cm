<?php
require_once( __DIR__ . '/ali-custom-tab.php' );

class Ali_Custom_Search_Result extends \Elementor\Widget_Base {

    public function __construct() {
        parent::__construct();
        $this->init_control();
    }

    public function get_name() {
        return 'ali-custom-search-results';
    }

    public function ali_register_controls( $element, $args ) {

        $element->start_controls_section(
            'ali_custom_search_results_section',
            [
                'label' => __( 'Ali Custom Search Result', 'ali' ),
                'tab' => Ali_Controls_Manager::TAB_ALI,
            ]
        );

        $element->add_control(
            'ali_custom_search_results_enable',
            [
                'label' => __( 'Enable', 'ali' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => '',
                'description' => __( 'This feature only works on the frontend.', 'ali' ),
                'label_on' => 'Yes',
                'label_off' => 'No',
                'return_value' => 'yes',
            ]
        );

        $post_types = get_post_types( [], 'objects' );
        $post_types_array = array( '' => 'None' );
        foreach ( $post_types as $post_type ) {
            $post_types_array[$post_type->name] = $post_type->label;
        }

        $element->add_control(
            'ali_custom_search_results_post_type',
            [
                'label' => __( 'Post Type', 'ali' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => $post_types_array,
                'condition' => [
                    'ali_custom_search_results_enable' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ali_custom_search_results_border_radius',
            [
                'label' => __( 'Border Radius', 'ali' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .ali-custom-search-results-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'ali_custom_search_results_enable' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ali_custom_search_results_border',
            [
                'label' => __( 'Border Type', 'ali' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '' => __( 'None', 'elementor' ),
                    'solid' => _x( 'Solid', 'Border Control', 'elementor' ),
                    'double' => _x( 'Double', 'Border Control', 'elementor' ),
                    'dotted' => _x( 'Dotted', 'Border Control', 'elementor' ),
                    'dashed' => _x( 'Dashed', 'Border Control', 'elementor' ),
                    'groove' => _x( 'Groove', 'Border Control', 'elementor' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .ali-custom-search-results-item' => 'border-style: {{VALUE}};',
                ],
                'condition' => [
                    'ali_custom_search_results_enable' => 'yes',
                ],
            ]
        );

        $element->add_responsive_control(
            'ali_custom_search_results_border_width',
            [
                'label' => __( 'Border Width', 'ali' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .ali-custom-search-results-item' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'ali_custom_search_results_enable' => 'yes',
                    'ali_custom_search_results_border!' => '',
                ],
            ]
        );

        $element->add_control(
            'ali_custom_search_results_border_color',
            [
                'label' => __( 'Border Color', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .ali-custom-search-results-item' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    'ali_custom_search_results_enable' => 'yes',
                    'ali_custom_search_results_border!' => '',
                ],
            ]
        );

        $element->add_control(
            'ali_custom_search_results_item_note',
            [
                'label' => __( 'Result Item', 'ali' ),
                'type' => \Elementor\Controls_Manager::RAW_HTML,
                'condition' => [
                    'ali_custom_search_results_enable' => 'yes',
                ],
            ]
        );

        $element->start_controls_tabs(
            'ali_custom_search_results_item',
            [
                'condition' => [
                    'ali_custom_search_results_enable' => 'yes',
                ],
            ]
        );

        $element->start_controls_tab(
            'ali_custom_search_results_item_normal',
            [
                'label' => __( 'Normal', 'elementor' ),
            ]
        );

        $element->add_responsive_control(
            'ali_custom_search_results_item_padding',
            [
                'label' => __( 'Padding', 'ali' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .ali-custom-search-results-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'ali_custom_search_results_enable' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ali_custom_search_results_item_color',
            [
                'label' => __( 'Color', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ali-custom-search-results-item' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'ali_custom_search_results_enable' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ali_custom_search_results_item_background_color',
            [
                'label' => __( 'Background Color', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ali-custom-search-results-item' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'ali_custom_search_results_enable' => 'yes',
                ],
            ]
        );

        $element->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'ali_custom_search_results_item_typography',
                'label' => __( 'Typography', 'ali' ),
                'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .ali-custom-search-results-item',
            ]
        );

        $element->end_controls_tab();

        $element->start_controls_tab(
            'ali_custom_search_results_item_hover',
            [
                'label' => __( 'Hover', 'elementor' ),
            ]
        );

        $element->add_responsive_control(
            'ali_custom_search_results_item_padding_hover',
            [
                'label' => __( 'Padding', 'ali' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .ali-custom-search-results-item:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'ali_custom_search_results_enable' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ali_custom_search_results_item_color_hover',
            [
                'label' => __( 'Color', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ali-custom-search-results-item:hover' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'ali_custom_search_results_enable' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ali_custom_search_results_item_background_color_hover',
            [
                'label' => __( 'Background Color', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ali-custom-search-results-item:hover' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'ali_custom_search_results_enable' => 'yes',
                ],
            ]
        );

        $element->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'ali_custom_search_results_item_typography_hover',
                'label' => __( 'Typography', 'ali' ),
                'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .ali-custom-search-results-item:hover',
            ]
        );

        $element->end_controls_tab();
        $element->end_controls_tabs();

        $element->end_controls_section();
    }

    function ali_enqueue_script() {
        wp_register_script( 'ali-custom-search-results-script', plugins_url('assets/js/minify/ali-custom-search-results.min.js', dirname( __FILE__ ) ), [ 'jquery' ], ALI_ADDONS_FOR_ELEMENTOR_VERSION );
        wp_enqueue_script( 'ali-custom-search-results-script');
        wp_register_style( 'ali-custom-search-results-style', plugins_url('assets/css/minify/ali-custom-search-results.min.css', dirname( __FILE__ ) ), [], ALI_ADDONS_FOR_ELEMENTOR_VERSION );
        wp_enqueue_style( 'ali-custom-search-results-style' );
        wp_localize_script( 'ali-custom-search-results-script', 'ali_custom_search_results_params', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) )  );
    }

    public function after_render_element($element) {
        $settings = $element->get_settings();
        if ( ! empty( $settings['ali_custom_search_results_enable'] ) ) {

            $element->add_render_attribute( '_wrapper', [
                'data-ali-custom-search-results' => $settings['ali_custom_search_results_post_type'],
            ] );
        }
    }
    public function before_content($element) {
        $settings = $element->get_settings_for_display();

        if ( isset($settings['ali_custom_search_results_enable']) && $settings['ali_custom_search_results_enable'] === 'yes' ) {
            add_action( 'elementor/frontend/before_enqueue_scripts', [$this, 'ali_enqueue_script'] );
        }
    }
    protected function init_control() {
        add_action( 'elementor/element/search-form/search_content/after_section_end', [ $this, 'ali_register_controls' ], 10, 2 );
        add_action( 'elementor/frontend/widget/before_render', [ $this, 'after_render_element'], 10, 1 );
        add_action( 'elementor/widget/before_render_content', [$this, 'before_content'] );
    }

}
