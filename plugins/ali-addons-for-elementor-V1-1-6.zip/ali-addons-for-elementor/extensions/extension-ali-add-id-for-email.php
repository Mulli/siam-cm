<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

class Ali_Add_ID_For_Email extends \ElementorPro\Modules\Forms\Classes\Action_Base {

    public function __construct()
    {
        add_action( 'init', [ $this, 'register_get_submission_id_shortcode' ] );
    }

    public function get_name() {
        return 'ali-add-id-for-email-submission';
    }

    public function get_label() {
        return esc_html__( 'Ali Add ID for Email Submission', 'ali' );
    }

    public function register_settings_section( $widget ) {

        $widget->start_controls_section(
            'section_ali_id_for_email',
            [
                'label' => esc_html__( 'Ali Add ID for Email Submission', 'ali' ),
            ]
        );

        $widget->add_control(
            'section_ali_id_for_email_enable',
            [
                'label' => __( 'Enable', 'ali' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => '',
                'description' => __( 'Copy this shortcode and Paste to Message input of Email or Email2', 'ali' ),
                'label_on' => 'Yes',
                'label_off' => 'No',
                'return_value' => 'yes',
            ]
        );

        $widget->add_control(
            'shortcode',
            [
                'label' => __( 'Shortcode', 'ali' ),
                'type' => \Elementor\Controls_Manager::RAW_HTML,
                'raw' => '<input style="margin-top: 10px" readonly value="[get_submission_id]"/>',
                'condition' => [
                    'section_ali_id_for_email_enable' => 'yes',
                ],
            ]
        );

        $widget->end_controls_section();

    }

    public function register_get_submission_id_shortcode() {
        add_shortcode( 'get_submission_id', [ $this, 'get_submission_id' ] );
    }

    public function get_submission_id() {
        global $wpdb;

        $sql = "SELECT MAX(ID) as max_id FROM `wp_e_submissions`;";
        $result = $wpdb->get_var( $sql );

        if ( $result ) {
            return  $result;
        } else {
            return 'No results found';
        }
    }

    public function run( $record, $ajax_handler ) {

    }

    public function on_export( $element ) {

        return $element;

    }

}