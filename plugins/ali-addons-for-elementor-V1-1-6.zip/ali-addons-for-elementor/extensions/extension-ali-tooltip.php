<?php
require_once( __DIR__ . '/ali-custom-tab.php' );

class Ali_Tooltip extends \Elementor\Widget_Base {

    public function __construct() {
        parent::__construct();
        $this->init_control();
    }

    public function get_name() {
        return 'ali-tooltip';
    }

    public function ali_register_controls( $element, $args ) {

        $element->start_controls_section(
            'ali_tooltip_section',
            [
                'label' => __( 'Ali Tooltip', 'ali' ),
                'tab' => Ali_Controls_Manager::TAB_ALI,
            ]
        );

        $element->add_control(
            'ali_tooltip',
            [
                'label' => __( 'Enable Tooltip', 'ali' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => '',
                'description' => __( 'This feature only works on the frontend.', 'ali' ),
                'label_on' => 'Yes',
                'label_off' => 'No',
                'return_value' => 'yes',
            ]
        );
        $element->add_control(
            'ali_tooltip_content_type',
            [
                'label' => __( 'Type', 'ali' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'content',
                'options' => [
                    'image'  => __( 'Image','ali' ),
                    'content' => __( 'Text Editor','ali' ),
                    'saved_template' => __( 'Elementor Template','ali' ),
                ],
                'condition' => [
                    'ali_tooltip' => 'yes',
                ]
            ]
        );

        $element->add_control(
            'ali_tooltip_content_wysiwyg',
            [
                'label' => __( 'Text Editor','ali' ),
                'type' => \Elementor\Controls_Manager::WYSIWYG,
                'condition' => [
                    'ali_tooltip_content_type' => 'content',
                    'ali_tooltip' => 'yes',
                ]
            ]
        );

        $element->add_control(
            'ali_tooltip_content_saved_template',
            [
                'label' => __( 'Shortcode', 'ali' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => __( 'Shortcode', 'ali' ),
                'condition' => [
                    'ali_tooltip_content_type' => 'saved_template'
                ]
            ]
        );

        $element->add_control(
            'ali_tooltip_content_image',
            [
                'label' => __( 'Choose Image', 'ali' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'ali_tooltip_content_type' => 'image',
                    'ali_tooltip' => 'yes',
                ]
            ]
        );

        $element->add_control(
            'ali_tooltip_duration',
            [
                'label' => __( 'Duration (ms)', 'ali' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => '300',
                'condition' => [
                    'ali_tooltip' => 'yes',
                ]
            ]
        );

        $element->add_control(
            'ali_tooltip_distance',
            [
                'label' => __( 'Distance', 'ali' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'size_units' => [ 'px' ],
                'default' => '5',
                'condition' => [
                    'ali_tooltip' => 'yes',
                ]
            ]
        );

        $element->add_control(
            'ali_tooltip_animation_type',
            [
                'label' => __( 'Animation Type', 'ali' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'scale',
                'options' => [
                    'scale'  => __( 'Scale','ali' ),
                    'fade' => __( 'Fade','ali' ),
                ],
                'condition' => [
                    'ali_tooltip' => 'yes',
                ]
            ]
        );

        $element->add_control(
            'ali_tooltip_placement',
            [
                'label' => __( 'Placement', 'ali' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'top',
                'options' => [
                    'top'  => __( 'Top','ali' ),
                    'right' => __( 'Right','ali' ),
                    'bottom' => __( 'Bottom','ali' ),
                    'left' => __( 'Left','ali' ),
                ],
                'condition' => [
                    'ali_tooltip' => 'yes',
                ]
            ]
        );

        $element->add_control(
            'ali_tooltip_content_color',
            [
                'label' => __( 'Content Color', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Core\Schemes\Color::get_type(),
                    'value' => \Elementor\Core\Schemes\Color::COLOR_1,
                ],
                'default' => '#fff',
                'selectors' => [
                    '{{WRAPPER}} [data-tippy-root] > .tippy-box' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'ali_tooltip' => 'yes',
                    'ali_tooltip_content_type' => 'content',
                ]
            ]
        );

        $element->add_control(
            'ali_tooltip_custom_width',
            [
                'label' => __( 'Custom Width', 'ali' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => '',
                'label_on' => 'Yes',
                'label_off' => 'No',
                'return_value' => 'yes',
            ]
        );

        $element->add_responsive_control(
            'ali_tooltip_content_width',
            [
                'label' => __( 'Width', 'ali' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px','%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} [data-tippy-root]' => 'width: {{SIZE}}{{UNIT}} !important; max-width: none !important;',
                    '{{WRAPPER}} [data-tippy-root] > .tippy-box' => 'max-width: none !important;',
                ],
                'condition' => [
                    'ali_tooltip' => 'yes',
                    'ali_tooltip_custom_width' => 'yes',
                ]
            ]
        );

        $element->add_control(
            'ali_tooltip_background_color',
            [
                'label' => __( 'Background Color', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Core\Schemes\Color::get_type(),
                    'value' => \Elementor\Core\Schemes\Color::COLOR_1,
                ],
                'default' => '#000',
                'selectors' => [
                    '{{WRAPPER}} [data-tippy-root] > .tippy-box' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} [data-tippy-root] > .tippy-box .tippy-arrow' => 'color: {{VALUE}}!important',
                ],
                'condition' => [
                    'ali_tooltip' => 'yes',
                ]
            ]
        );

        $element->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'ali_tooltip_label_typography',
                'selector' => '{{WRAPPER}} [data-tippy-root] > .tippy-box',
                'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_4,
                'condition' => [
                    'ali_tooltip' => 'yes',
                    'ali_tooltip_content_type' => 'content',
                ]
            ]
        );
        $element->end_controls_section();
    }

    public function after_render_element($element) {
        $settings = $element->get_settings();
        if ( !empty( $settings['ali_tooltip'] ) ) {
            $tippy_options = [
                'duration' => absint( $settings['ali_tooltip_duration'] ),
                'animation' => $settings['ali_tooltip_animation_type'],
                'distance' => floatval( $settings['ali_tooltip_distance'] ),
                'placement' => $settings['ali_tooltip_placement'],
                'allowHTML'=> true,
            ];

            $content = '';
            if ($settings['ali_tooltip_content_type'] == 'content') {
                $content = $settings['ali_tooltip_content_wysiwyg'];
            } elseif ($settings['ali_tooltip_content_type'] == 'image') {
                $content = '<img src="'. $settings['ali_tooltip_content_image']['url'] . '"alt="">';
            } elseif ($settings['ali_tooltip_content_type'] == 'saved_template') {
                $content = do_shortcode($settings['ali_tooltip_content_saved_template']);
            }
            $element->add_render_attribute( '_wrapper', [
                'data-tippy-content' => $content,
                'data-ali-tippy-options' => json_encode( $tippy_options ),
            ]);
        }
    }

    protected function init_control() {
        add_action( 'elementor/element/section/section_advanced/after_section_end', [ $this, 'ali_register_controls' ], 10, 2 );
        add_action( 'elementor/element/container/section_layout/after_section_end', [ $this, 'ali_register_controls' ], 10, 2 );
        add_action( 'elementor/element/column/section_advanced/after_section_end', [ $this, 'ali_register_controls' ], 10, 2 );
        add_action( 'elementor/element/common/_section_background/after_section_end', [ $this, 'ali_register_controls' ], 10, 2 );
        add_action( 'elementor/frontend/section/before_render', [ $this, 'after_render_element'], 10, 1 );
        add_action( 'elementor/frontend/column/before_render', [ $this, 'after_render_element'], 10, 1 );
        add_action( 'elementor/frontend/container/before_render', [ $this, 'after_render_element'], 10, 1 );
        add_action( 'elementor/frontend/widget/before_render', [ $this, 'after_render_element'], 10, 1 );
        add_action( 'elementor/widget/before_render_content', [$this, 'before_content'] );

    }

    public function before_content($element) {
        $settings = $element->get_settings_for_display();
        if ( isset($settings['ali_tooltip']) && $settings['ali_tooltip'] === 'yes' ) {
            add_action( 'elementor/frontend/before_enqueue_scripts', [$this, 'ali_register_script'] );
        }
    }

    public function ali_register_script() {
        wp_register_script( 'ali-tooltip-script', plugins_url('assets/js/minify/ali-tooltip.min.js', dirname( __FILE__ ) ), [ 'jquery' ], ALI_ADDONS_FOR_ELEMENTOR_VERSION );
        wp_enqueue_script( 'ali-tooltip-script');

        wp_register_style( 'ali-tooltip-style', plugins_url('assets/css/minify/ali-tooltip.min.css', dirname( __FILE__ ) ), [], ALI_ADDONS_FOR_ELEMENTOR_VERSION );
        wp_enqueue_style( 'ali-tooltip-style' );
    }

}	
