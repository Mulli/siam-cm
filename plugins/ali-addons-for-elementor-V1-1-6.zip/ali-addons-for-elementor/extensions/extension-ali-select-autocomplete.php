<?php
namespace Elementor;

use Elementor\Controls_Manager;

class Ali_Select_Autocomplete_Field {
    public $allowed_fields = [
        'select',
    ];

    public function __construct() {
        add_filter( 'elementor_pro/forms/render/item', [ $this, 'render' ], 10, 3 );
        add_action( 'elementor-pro/forms/pre_render', [$this, 'before_content'] );
        add_action( 'elementor/element/form/section_form_fields/before_section_end', [ $this, 'ali_custom_field_control' ], 100, 2 );
        add_action('elementor/element/form/section_form_style/after_section_end', [$this, 'ali_select_autocomplete_style']);

    }

    public function ali_custom_field_control( $element, $args ) {
        $elementor = \Elementor\Plugin::instance();
        $control_data = $elementor->controls_manager->get_control_from_stack( $element->get_name(), 'form_fields' );

        if ( is_wp_error( $control_data ) ) {
            return;
        }
        $field_new_controls = [
            'form_fields_ali_select_autocomplete_enabled' => [
                'name'         => 'form_fields_ali_select_autocomplete_enabled',
                'label'        => __('Enable Ali Select Autocomplete Field', 'ali'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => 'Yes',
                'label_off'    => 'No',
                'tab'          => 'form_fields_content_tab',
                'tabs_wrapper' => 'form_fields_tabs',
                'inner_tab'    => 'form_fields_content_tab',
                'conditions' => [
                    'terms' => [
                        [
                            'name'     => 'field_type',
                            'operator' => 'in',
                            'value'    => ['select']
                        ]
                    ]
                ],
            ],
        ];

        $field_control_data['fields'] = $control_data['fields'] + $field_new_controls;
        $element->update_control('form_fields', $field_control_data);
    }

    public function ali_select_autocomplete_style ($widget) {
        $widget->start_controls_section(
            'ali_select_autocomplete_styles',
            [
                'label' => __('Select Autocomplete', 'ali'),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );

        $widget->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'ali_select_autocomplete_typography',
                'selector' => '{{WRAPPER}} .selectize-dropdown-content'
            ]
        );

        $widget->add_control(
            'ali_select_autocomplete_background_color',
            [
                'label' => esc_html__('Dropdown Background Color', 'ali'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .selectize-dropdown-content' => 'background: {{VALUE}} !important;'
                ]
            ]
        );

        $widget->add_control(
            'ali_select_autocomplete_padding',
            [
                'label' => esc_html__('Dropdown Padding', 'ali'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .selectize-dropdown' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $widget->start_controls_tabs('ali_select_button_style_tabs');
        $widget->start_controls_tab(
            'ali_select_button_normal',
            [
                'label' => __('Normal', 'ali')
            ]
        );
        $widget->add_control(
            'ali_select_autocomplete_item_background_color_normal',
            [
                'label' => esc_html__('Background Color', 'ali'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .selectize-dropdown-content .option' => 'background: {{VALUE}} !important;'
                ]
            ]
        );

        $widget->add_control(
            'ali_select_autocomplete_text_color_normal',
            [
                'label' => esc_html__('Text Color', 'ali'),
                'type' => Controls_Manager::COLOR,
                'default' => '#000',
                'selectors' => [
                    '{{WRAPPER}} .selectize-dropdown-content .option' => 'color: {{VALUE}} !important;'
                ]
            ]
        );
        $widget->end_controls_tab();

        $widget->start_controls_tab(
            'ali_select_autocomplete_hover',
            [
                'label' => __('Hover', 'ali')
            ]
        );
        $widget->add_control(
            'ali_select_autocomplete_item_background_color_hover',
            [
                'label' => esc_html__('Background Color', 'ali'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .selectize-dropdown-content .option:hover' => 'background: {{VALUE}} !important;'
                ]
            ]
        );

        $widget->add_control(
            'ali_select_autocomplete_text_color_hover',
            [
                'label' => esc_html__('Text Color', 'ali'),
                'type' => Controls_Manager::COLOR,
                'default' => '#000',
                'selectors' => [
                    '{{WRAPPER}} .selectize-dropdown-content .option:hover' => 'color: {{VALUE}} !important;'
                ]
            ]
        );

        $widget->end_controls_tab();
        $widget->end_controls_tabs();

        $widget->end_controls_section();

    }


    public function ali_register_script() {
        wp_register_script( 'ali-select-autocomplete-script', plugins_url('assets/js/minify/ali-select-autocomplete.min.js', dirname( __FILE__ ) ), [ 'jquery' ], ALI_ADDONS_FOR_ELEMENTOR_VERSION);
        wp_enqueue_script( 'ali-select-autocomplete-script');

        wp_register_style( 'ali-select-autocomplete-style', plugins_url('assets/css/minify/ali-select-autocomplete.min.css', dirname( __FILE__ ) ), [], ALI_ADDONS_FOR_ELEMENTOR_VERSION );
        wp_enqueue_style( 'ali-select-autocomplete-style' );
    }

    public function before_content($element){
        if(!empty($element['form_fields']) && is_array($element['form_fields'])){
            array_walk($element['form_fields'], function($field, $key){
                if($field['form_fields_ali_select_autocomplete_enabled'] === 'yes'){
                    add_action( 'elementor/frontend/before_enqueue_scripts', [$this, 'ali_register_script'] );
                }
            });
        }
    }

    public function render( $field, $field_index, $form_widget ) {
        if ( ! empty( $field['form_fields_ali_select_autocomplete_enabled'] ) && in_array( $field['field_type'], $this->allowed_fields ) ) {
            $form_widget->add_render_attribute( 'select' . $field_index, 'data-ali-select-autocomplete', '' );
        }
        return $field;
    }
}
