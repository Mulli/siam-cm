<?php
require_once( __DIR__ . '/ali-custom-tab.php' );

class Ali_Preview_Data extends \Elementor\Widget_Base
{

    public function __construct()
    {
        parent::__construct();
        $this->init_control();
    }

    public function get_name()
    {
        return 'ali-preview-data';
    }

    public function ali_register_script()
    {
        wp_register_style( 'ali-preview-form-data-style', plugins_url('assets/css/minify/ali-preview-form-data.min.css', dirname( __FILE__ ) ), [], ALI_ADDONS_FOR_ELEMENTOR_VERSION );
        wp_enqueue_style( 'ali-preview-form-data-style' );

        wp_register_script( 'ali-preview-form-data-script', plugins_url('assets/js/minify/ali-preview-data.min.js', dirname( __FILE__ ) ), [ 'jquery' ], ALI_ADDONS_FOR_ELEMENTOR_VERSION );
        wp_localize_script( 'ali-preview-form-data-script', 'ali_preview_form_data_params', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) )  );
        wp_enqueue_script( 'ali-preview-form-data-script');

    }

    public function ali_register_controls($element, $args){

        $element->start_controls_section(
            'ali_preview_data_section',
            [
                'label' => __('Ali Preview Data', 'ali'),
                'tab' => Ali_Controls_Manager::TAB_ALI,
            ]
        );

        $element->add_control(
            'ali_preview_data_enable',
            [
                'label' => __('Enable', 'ali'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => '',
                'description' => __('This feature only works on the frontend.', 'ali'),
                'label_on' => 'Yes',
                'label_off' => 'No',
                'return_value' => 'yes',
            ]
        );

        $element->add_control(
            'ali_preview_data_title',
            [
                'label' => __( 'Title', 'ali' ),
                'type' => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $element->end_controls_section();
        
        $element->start_controls_section(
            'ali_preview_data_style_section',
            [
                'label' => __( 'Ali Preview Data Style', 'ali' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ali_preview_data_enable' => 'yes',
                ],
            ]
        );

        $element->add_responsive_control(
            'ali_preview_data_padding',
            [
                'label' => __( 'Padding', 'ali' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .ali-preview-form-data' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'ali_preview_data_enable' => 'yes',
                ],
            ]
        );

        $element->add_responsive_control(
            'ali_preview_data_margin',
            [
                'label' => __( 'Margin', 'ali' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .ali-preview-form-data' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'ali_preview_data_enable' => 'yes',
                ],
            ]
        );
        
        $element->add_control(
            'ali_preview_data_background_color',
            [
                'label' => __( 'Background Color', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .ali-preview-form-data' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'ali_preview_data_enable' => 'yes',
                ],
            ]
        );
        
        $element->add_control(
            'ali_preview_data_border',
            [
                'label' => __( 'Item Border Type', 'ali' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '' => __( 'None', 'elementor' ),
                    'solid' => _x( 'Solid', 'Border Control', 'elementor' ),
                    'double' => _x( 'Double', 'Border Control', 'elementor' ),
                    'dotted' => _x( 'Dotted', 'Border Control', 'elementor' ),
                    'dashed' => _x( 'Dashed', 'Border Control', 'elementor' ),
                    'groove' => _x( 'Groove', 'Border Control', 'elementor' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .ali-preview-form-data' => 'border-style: {{VALUE}};',
                ],
                'condition' => [
                    'ali_preview_data_enable' => 'yes',
                ],
            ]
        );

        $element->add_responsive_control(
            'ali_preview_data_border_width',
            [
                'label' => __( 'Item Border Width', 'ali' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .ali-preview-form-data' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'ali_preview_data_border!' => '',
                    'ali_preview_data_enable' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ali_preview_data_border_color',
            [
                'label' => __( 'Item Border Color', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .ali-preview-form-data' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    'ali_preview_data_border!' => '',
                    'ali_preview_data_enable' => 'yes',
                ],
            ]
        );
        $element->start_controls_tabs('ali_preview_data_label_value');

        $element->start_controls_tab(
            'ali_preview_data_title_style',
            [
                'label' => __( 'Title', 'ali' ),
                'condition' => [
                    'ali_preview_data_enable' => 'yes',
                ],
            ]
        );
        $element->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'ali_preview_data_title_typography',
                'label' => __( 'Typography', 'ali' ),
                'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .ali-preview-title',
                'condition' => [
                    'ali_preview_data_enable' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ali_preview_data_title_color',
            [
                'label' => __( 'Label Color', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .ali-preview-title' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'ali_preview_data_enable' => 'yes',
                ],
            ]
        );

        $element->add_responsive_control(
            'ali_preview_data_title_text_align',
            [
                'label' => __( 'Text Align', 'ali' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'elementor' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'elementor' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'elementor' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .ali-preview-title' => 'text-align: {{VALUE}};',
                ],
                'condition' => [
                    'ali_preview_data_enable' => 'yes',
                ],
            ]
        );

        $element->end_controls_tab();

        $element->start_controls_tab(
            'ali_preview_data_label_style',
            [
                'label' => __( 'Label', 'ali' ),
                'condition' => [
                    'ali_preview_data_enable' => 'yes',
                ],
            ]
        );
        $element->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'ali_preview_data_label_typography',
                'label' => __( 'Typography', 'ali' ),
                'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .ali-preview__item-label',
                'condition' => [
                    'ali_preview_data_enable' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ali_preview_data_label_color',
            [
                'label' => __( 'Label Color', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .ali-preview__item-label' => 'color: {{VALUE}};',
                ],
            ]
        );

        $element->end_controls_tab();

        $element->start_controls_tab(
            'ali_preview_data_value_style',
            [
                'label' => __( 'Value', 'ali' ),
                'condition' => [
                    'ali_preview_data_enable' => 'yes',
                ],
            ]
        );
        $element->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'ali_preview_data_value_typography',
                'label' => __( 'Typography', 'ali' ),
                'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .ali-preview__item-value',
                'condition' => [
                    'ali_preview_data_enable' => 'yes',
                ],
            ]
        );

        $element->add_control(
            'ali_preview_data_value_color',
            [
                'label' => __( 'Value Color', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .ali-preview__item-value' => 'color: {{VALUE}};',
                ],
            ]
        );

        $element->end_controls_tab();
        $element->end_controls_tabs();

        $element->end_controls_section();

    }

    public function before_render_element($element){
        $settings = $element->get_settings();
        if (!empty($settings['ali_preview_data_enable'])) {
            $element->add_render_attribute('_wrapper', [
                'data-ali-preview-form' => $settings['ali_preview_data_title'],
            ]);

        }
    }

    public function before_content($element)
    {
        $settings = $element->get_settings_for_display();
        if ( isset($settings['ali_preview_data_enable']) && $settings['ali_preview_data_enable'] === 'yes' ) {
            add_action( 'elementor/frontend/before_enqueue_scripts', [$this, 'ali_register_script'] );

        }

    }

    protected function init_control()
    {
        add_action('elementor/element/form/section_form_fields/after_section_end', [$this, 'ali_register_controls'], 10, 2);
        add_action('elementor/frontend/widget/before_render', [$this, 'before_render_element'], 10, 1);
        add_action('elementor/widget/before_render_content', [$this, 'before_content']);
    }

}
