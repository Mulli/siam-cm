<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

class Ali_Signature_Field extends \ElementorPro\Modules\Forms\Fields\Field_Base {
    
    public function __construct() {
        parent::__construct();
        add_action( 'elementor/preview/init', [ $this, 'editor_preview_footer' ] );
        add_action( 'elementor-pro/forms/pre_render', [$this, 'before_content'] );
        add_action('elementor/element/form/section_form_style/after_section_end', [$this, 'style_controls']);
        add_action( 'elementor/element/form/section_form_fields/before_section_end', [ $this, 'ali_custom_field_control' ], 100, 2 );
    }

    public function get_type() {
        return 'ali-signature-field';
    }

    public function get_name() {
        return esc_html__( 'Ali Signature Field', 'ali' );
    }

    public function ali_custom_field_control( $element, $args ) {
        $elementor = \Elementor\Plugin::instance();
        $control_data = $elementor->controls_manager->get_control_from_stack( $element->get_name(), 'form_fields' );

        if ( is_wp_error( $control_data ) ) {
            return;
        }
        $field_new_controls = [
            'ali_signature_field_clear_text' => [
                'name' => 'ali_signature_field_clear_text',
                'label' => esc_html__( 'Clear Text', 'ali' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Clear',
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'field_type' => $this->get_type(),
                ],
                'tab'          => 'content',
                'inner_tab'    => 'form_fields_content_tab',
                'tabs_wrapper' => 'form_fields_tabs',
            ],
            'ali_signature_field_add_to_mail' => [
                'name' => 'ali_signature_field_add_to_mail',
                'label' => esc_html__( 'Add signature file to email', 'ali' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => 'Yes',
                'label_off'    => 'No',
                'condition' => [
                    'field_type' => $this->get_type(),
                ],
                'tab'          => 'content',
                'inner_tab'    => 'form_fields_content_tab',
                'tabs_wrapper' => 'form_fields_tabs',
            ],
        ];

        $field_control_data['fields'] = $control_data['fields'] + $field_new_controls;
        $element->update_control('form_fields', $field_control_data);
    }

    public function style_controls($widget)
    {
        $widget->start_controls_section(
            'ali_signature_field_styles',
            [
                'label' => esc_html__('Ali Signature Field', 'ali'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            ]
        );
        $widget->add_responsive_control(
            'ali_signature_field_width',
            [
                'label' => __( 'Width', 'ali' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 400,
                'min' => 1,
                'max' => 1000,
            ]
        );
        $widget->add_responsive_control(
            'ali_signature_field_height',
            [
                'label' => __( 'Height', 'ali' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 200,
                'min' => 1,
                'max' => 1000,
            ]
        );

        $widget->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'ali_signature_field_typography',
                'selector' => '{{WRAPPER}} .ali-signature-clear'
            ]
        );

        $widget->add_responsive_control(
            'ali_signature_field_padding',
            [
                'label' => __( 'Padding', 'ali' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .ali-signature-clear' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $widget->start_controls_tabs('ali_reset_button_style_tabs');
        $widget->start_controls_tab(
            'ali_reset_button_normal',
            [
                'label' => __('Normal', 'ali')
            ]
        );
        $widget->add_control(
            'ali_signature_field_background_color_normal',
            [
                'label' => esc_html__('Background Color', 'ali'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffbd5a',
                'selectors' => [
                    '{{WRAPPER}} .ali-signature-clear' => 'background: {{VALUE}} !important;'
                ]
            ]
        );

        $widget->add_control(
            'ali_signature_field_text_color_normal',
            [
                'label' => esc_html__('Text Color', 'ali'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .ali-signature-clear' => 'color: {{VALUE}} !important;'
                ]
            ]
        );
        $widget->end_controls_tab();

        $widget->start_controls_tab(
            'ali_signature_field_hover',
            [
                'label' => __('Hover', 'ali')
            ]
        );
        $widget->add_control(
            'ali_signature_field_background_color_hover',
            [
                'label' => esc_html__('Background Color', 'ali'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffbd5a',
                'selectors' => [
                    '{{WRAPPER}} .ali-signature-clear:hover' => 'background: {{VALUE}} !important;'
                ]
            ]
        );

        $widget->add_control(
            'ali_signature_field_text_color_hover',
            [
                'label' => esc_html__('Text Color', 'ali'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .ali-signature-clear:hover' => 'color: {{VALUE}} !important;'
                ]
            ]
        );

        $widget->end_controls_tab();
        $widget->end_controls_tabs();
        $widget->add_control(
            'ali_custom_search_results_border_radius',
            [
                'label' => __( 'Border Radius', 'ali' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .ali-signature-clear' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $widget->add_control(
            'ali_custom_search_results_border',
            [
                'label' => __( 'Border Type', 'ali' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '' => __( 'None', 'elementor' ),
                    'solid' => _x( 'Solid', 'Border Control', 'elementor' ),
                    'double' => _x( 'Double', 'Border Control', 'elementor' ),
                    'dotted' => _x( 'Dotted', 'Border Control', 'elementor' ),
                    'dashed' => _x( 'Dashed', 'Border Control', 'elementor' ),
                    'groove' => _x( 'Groove', 'Border Control', 'elementor' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .ali-signature-clear' => 'border-style: {{VALUE}};',
                ],
            ]
        );

        $widget->add_responsive_control(
            'ali_custom_search_results_border_width',
            [
                'label' => __( 'Border Width', 'ali' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .ali-signature-clear' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],

            ]
        );

        $widget->add_control(
            'ali_custom_search_results_border_color',
            [
                'label' => __( 'Border Color', 'ali' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .ali-signature-clear' => 'border-color: {{VALUE}};',
                ],
            ]
        );
        $widget->end_controls_section();
    }
    
    public function render( $item, $item_index, $form ) {
        $settings = $form->get_settings_for_display();

        echo '<div class="ali-signature" data-ali-signature><canvas class="not-resize" style="max-width: 100%;" width="'.$settings['ali_signature_field_width'] .'" height="'.$settings['ali_signature_field_height'] .'"></canvas>';
        echo'<input '. $form->get_render_attribute_string('input' . $item_index).'>';
        echo '<div>';
        echo '<button type="button" class="ali-signature-clear" data-ali-signature-clear>'.$item["ali_signature_field_clear_text"].'</button>';
        echo '</div>';
        echo '</div>';
    }

    public function validation( $field, $record, $ajax_handler ) {
        if ( empty( $field['value'] ) ) {
            return;
        }
    }
    public $attachments_array = [];
    public function process_field($field, $record, $ajax){
        $settings = $record->get('form_settings');
        $raw_value = $field['raw_value'];
        $signature_file = $this->upload_file($raw_value, $field['id']);
        $record->update_field($field['id'], 'value', $signature_file);
        foreach ( $settings['form_fields'] as $index => $item) {
            if ( $item['ali_signature_field_add_to_mail'] === 'yes') {
                $file_name = basename($signature_file);
                $this->attachments_array[] = wp_get_upload_dir()['path'] . '/' . $file_name;
            }
            add_filter( 'wp_mail', [ $this, 'wp_mail' ] );
            add_action( 'elementor_pro/forms/new_record', [ $this, 'remove_wp_mail_filter' ], 5 );
        }

    }

    public function remove_wp_mail_filter() {
        $this->attachments_array = [];
        remove_filter( 'wp_mail', [ $this, 'wp_mail' ] );
    }

    public function wp_mail( $args ) {
        $args['attachments'] = array_merge($this->attachments_array);
        return $args;
    }

    function upload_file( $base64_img, $title ) {
        // Replace special characters
        $title = str_replace(array("\\", "/"), "_", $title);
        $title = str_replace(array(":", "*", "?", "\"", "<", ">", "|"), "", $title);

        // Upload dir.
        $upload_dir  = wp_upload_dir();
        $upload_path = str_replace( '/', DIRECTORY_SEPARATOR, $upload_dir['path'] ) . DIRECTORY_SEPARATOR;
        $file_type       = 'image/png';
        $data_uri = $base64_img;
        $encoded_image = explode(",", $data_uri)[1];
        $decoded = base64_decode($encoded_image);
        $hashed_filename = $title . '_' . md5( $title . microtime() ) .'.png';

        $upload_file = file_put_contents( $upload_path . $hashed_filename, $decoded );

        $attachment = array(
            'post_mime_type' => $file_type,
            'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $hashed_filename ) ),
            'post_content'   => '',
            'post_status'    => 'inherit',
            'guid'           => $upload_dir['url'] . '/' . basename( $hashed_filename )
        );

        $full_path = $upload_dir['path'] . '/' . $hashed_filename;
        $attach_id = wp_insert_attachment( $attachment, $full_path );

        $attach_data = wp_generate_attachment_metadata( $attach_id, $full_path );
        wp_update_attachment_metadata( $attach_id, $attach_data );

        $attachment_url = wp_get_attachment_image_src($attach_id,'full')[0];
        $attachment_url = preg_replace_callback('#://([^/]+)/([^?]+)#', function ($match) {
            return '://' . $match[1] . '/' . join('/', array_map('rawurlencode', explode('/', $match[2])));
        }, $attachment_url);
        return $attachment_url;
    }

    public function before_content($element){
        add_action( 'elementor/frontend/before_enqueue_scripts', [$this, 'ali_register_script'] );
    }

    public function ali_register_script() {
        wp_register_script( 'ali-signature-script', plugins_url('assets/js/minify/ali-signature-field.min.js', dirname( __FILE__ ) ), [ 'jquery' ], ALI_ADDONS_FOR_ELEMENTOR_VERSION );
        wp_enqueue_script( 'ali-signature-script');

        wp_register_style( 'ali-signature-field-style', plugins_url('assets/css/minify/ali-signature-field.min.css', dirname( __FILE__ ) ), [], ALI_ADDONS_FOR_ELEMENTOR_VERSION );
        wp_enqueue_style( 'ali-signature-field-style' );
    }

    public function editor_preview_footer() {
        add_action( 'wp_footer', [ $this, 'content_template_script' ] );
    }
    
    public function content_template_script() {
        ?>
            <style>
                .ali-signature > .elementor-field {
                    display: none !important;
                }

                .ali-signature {
                    display: block;
                    width: 100%;
                }

                .ali-signature canvas {
                    border: 1px solid #ccc;
                    border-radius: 3px;
                }
            </style>
        <script type="text/javascript">
            !function(t,e){"object"==typeof exports&&"undefined"!=typeof module?module.exports=e():"function"==typeof define&&define.amd?define(e):(t="undefined"!=typeof globalThis?globalThis:t||self).SignaturePad=e()}(this,(function(){"use strict";class t{constructor(t,e,i,n){if(isNaN(t)||isNaN(e))throw new Error(`Point is invalid: (${t}, ${e})`);this.x=+t,this.y=+e,this.pressure=i||0,this.time=n||Date.now()}distanceTo(t){return Math.sqrt(Math.pow(this.x-t.x,2)+Math.pow(this.y-t.y,2))}equals(t){return this.x===t.x&&this.y===t.y&&this.pressure===t.pressure&&this.time===t.time}velocityFrom(t){return this.time!==t.time?this.distanceTo(t)/(this.time-t.time):0}}class e{constructor(t,e,i,n,s,o){this.startPoint=t,this.control2=e,this.control1=i,this.endPoint=n,this.startWidth=s,this.endWidth=o}static fromPoints(t,i){const n=this.calculateControlPoints(t[0],t[1],t[2]).c2,s=this.calculateControlPoints(t[1],t[2],t[3]).c1;return new e(t[1],n,s,t[2],i.start,i.end)}static calculateControlPoints(e,i,n){const s=e.x-i.x,o=e.y-i.y,h=i.x-n.x,r=i.y-n.y,a=(e.x+i.x)/2,d=(e.y+i.y)/2,l=(i.x+n.x)/2,c=(i.y+n.y)/2,u=Math.sqrt(s*s+o*o),v=Math.sqrt(h*h+r*r),m=v/(u+v),_=l+(a-l)*m,p=c+(d-c)*m,g=i.x-_,x=i.y-p;return{c1:new t(a+g,d+x),c2:new t(l+g,c+x)}}length(){let t,e,i=0;for(let n=0;n<=10;n+=1){const s=n/10,o=this.point(s,this.startPoint.x,this.control1.x,this.control2.x,this.endPoint.x),h=this.point(s,this.startPoint.y,this.control1.y,this.control2.y,this.endPoint.y);if(n>0){const n=o-t,s=h-e;i+=Math.sqrt(n*n+s*s)}t=o,e=h}return i}point(t,e,i,n,s){return e*(1-t)*(1-t)*(1-t)+3*i*(1-t)*(1-t)*t+3*n*(1-t)*t*t+s*t*t*t}}class i extends EventTarget{constructor(t,e={}){super(),this.canvas=t,this.options=e,this._handleMouseDown=t=>{1===t.buttons&&(this._drawningStroke=!0,this._strokeBegin(t))},this._handleMouseMove=t=>{this._drawningStroke&&this._strokeMoveUpdate(t)},this._handleMouseUp=t=>{1===t.buttons&&this._drawningStroke&&(this._drawningStroke=!1,this._strokeEnd(t))},this._handleTouchStart=t=>{if(t.preventDefault(),1===t.targetTouches.length){const e=t.changedTouches[0];this._strokeBegin(e)}},this._handleTouchMove=t=>{t.preventDefault();const e=t.targetTouches[0];this._strokeMoveUpdate(e)},this._handleTouchEnd=t=>{if(t.target===this.canvas){t.preventDefault();const e=t.changedTouches[0];this._strokeEnd(e)}},this._handlePointerStart=t=>{this._drawningStroke=!0,t.preventDefault(),this._strokeBegin(t)},this._handlePointerMove=t=>{this._drawningStroke&&(t.preventDefault(),this._strokeMoveUpdate(t))},this._handlePointerEnd=t=>{this._drawningStroke=!1;t.target===this.canvas&&(t.preventDefault(),this._strokeEnd(t))},this.velocityFilterWeight=e.velocityFilterWeight||.7,this.minWidth=e.minWidth||.5,this.maxWidth=e.maxWidth||2.5,this.throttle="throttle"in e?e.throttle:16,this.minDistance="minDistance"in e?e.minDistance:5,this.dotSize=e.dotSize||0,this.penColor=e.penColor||"black",this.backgroundColor=e.backgroundColor||"rgba(0,0,0,0)",this._strokeMoveUpdate=this.throttle?function(t,e=250){let i,n,s,o=0,h=null;const r=()=>{o=Date.now(),h=null,i=t.apply(n,s),h||(n=null,s=[])};return function(...a){const d=Date.now(),l=e-(d-o);return n=this,s=a,l<=0||l>e?(h&&(clearTimeout(h),h=null),o=d,i=t.apply(n,s),h||(n=null,s=[])):h||(h=window.setTimeout(r,l)),i}}(i.prototype._strokeUpdate,this.throttle):i.prototype._strokeUpdate,this._ctx=t.getContext("2d"),this.clear(),this.on()}clear(){const{_ctx:t,canvas:e}=this;t.fillStyle=this.backgroundColor,t.clearRect(0,0,e.width,e.height),t.fillRect(0,0,e.width,e.height),this._data=[],this._reset(),this._isEmpty=!0}fromDataURL(t,e={}){return new Promise((i,n)=>{const s=new Image,o=e.ratio||window.devicePixelRatio||1,h=e.width||this.canvas.width/o,r=e.height||this.canvas.height/o,a=e.xOffset||0,d=e.yOffset||0;this._reset(),s.onload=()=>{this._ctx.drawImage(s,a,d,h,r),i()},s.onerror=t=>{n(t)},s.crossOrigin="anonymous",s.src=t,this._isEmpty=!1})}toDataURL(t="image/png",e){switch(t){case"image/svg+xml":return this._toSVG();default:return this.canvas.toDataURL(t,e)}}on(){this.canvas.style.touchAction="none",this.canvas.style.msTouchAction="none",window.PointerEvent?this._handlePointerEvents():(this._handleMouseEvents(),"ontouchstart"in window&&this._handleTouchEvents())}off(){this.canvas.style.touchAction="auto",this.canvas.style.msTouchAction="auto",this.canvas.removeEventListener("pointerdown",this._handlePointerStart),this.canvas.removeEventListener("pointermove",this._handlePointerMove),document.removeEventListener("pointerup",this._handlePointerEnd),this.canvas.removeEventListener("mousedown",this._handleMouseDown),this.canvas.removeEventListener("mousemove",this._handleMouseMove),document.removeEventListener("mouseup",this._handleMouseUp),this.canvas.removeEventListener("touchstart",this._handleTouchStart),this.canvas.removeEventListener("touchmove",this._handleTouchMove),this.canvas.removeEventListener("touchend",this._handleTouchEnd)}isEmpty(){return this._isEmpty}fromData(t,{clear:e=!0}={}){e&&this.clear(),this._fromData(t,this._drawCurve.bind(this),this._drawDot.bind(this)),this._data=e?t:this._data.concat(t)}toData(){return this._data}_strokeBegin(t){this.dispatchEvent(new CustomEvent("beginStroke",{detail:t}));const e={dotSize:this.dotSize,minWidth:this.minWidth,maxWidth:this.maxWidth,penColor:this.penColor,points:[]};this._data.push(e),this._reset(),this._strokeUpdate(t)}_strokeUpdate(t){if(0===this._data.length)return void this._strokeBegin(t);this.dispatchEvent(new CustomEvent("beforeUpdateStroke",{detail:t}));const e=t.clientX,i=t.clientY,n=void 0!==t.pressure?t.pressure:void 0!==t.force?t.force:0,s=this._createPoint(e,i,n),o=this._data[this._data.length-1],h=o.points,r=h.length>0&&h[h.length-1],a=!!r&&s.distanceTo(r)<=this.minDistance,{penColor:d,dotSize:l,minWidth:c,maxWidth:u}=o;if(!r||!r||!a){const t=this._addPoint(s);r?t&&this._drawCurve(t,{penColor:d,dotSize:l,minWidth:c,maxWidth:u}):this._drawDot(s,{penColor:d,dotSize:l,minWidth:c,maxWidth:u}),h.push({time:s.time,x:s.x,y:s.y,pressure:s.pressure})}this.dispatchEvent(new CustomEvent("afterUpdateStroke",{detail:t}))}_strokeEnd(t){this._strokeUpdate(t),this.dispatchEvent(new CustomEvent("endStroke",{detail:t}))}_handlePointerEvents(){this._drawningStroke=!1,this.canvas.addEventListener("pointerdown",this._handlePointerStart),this.canvas.addEventListener("pointermove",this._handlePointerMove),document.addEventListener("pointerup",this._handlePointerEnd)}_handleMouseEvents(){this._drawningStroke=!1,this.canvas.addEventListener("mousedown",this._handleMouseDown),this.canvas.addEventListener("mousemove",this._handleMouseMove),document.addEventListener("mouseup",this._handleMouseUp)}_handleTouchEvents(){this.canvas.addEventListener("touchstart",this._handleTouchStart),this.canvas.addEventListener("touchmove",this._handleTouchMove),this.canvas.addEventListener("touchend",this._handleTouchEnd)}_reset(){this._lastPoints=[],this._lastVelocity=0,this._lastWidth=(this.minWidth+this.maxWidth)/2,this._ctx.fillStyle=this.penColor}_createPoint(e,i,n){const s=this.canvas.getBoundingClientRect();return new t(e-s.left,i-s.top,n,(new Date).getTime())}_addPoint(t){const{_lastPoints:i}=this;if(i.push(t),i.length>2){3===i.length&&i.unshift(i[0]);const t=this._calculateCurveWidths(i[1],i[2]),n=e.fromPoints(i,t);return i.shift(),n}return null}_calculateCurveWidths(t,e){const i=this.velocityFilterWeight*e.velocityFrom(t)+(1-this.velocityFilterWeight)*this._lastVelocity,n=this._strokeWidth(i),s={end:n,start:this._lastWidth};return this._lastVelocity=i,this._lastWidth=n,s}_strokeWidth(t){return Math.max(this.maxWidth/(t+1),this.minWidth)}_drawCurveSegment(t,e,i){const n=this._ctx;n.moveTo(t,e),n.arc(t,e,i,0,2*Math.PI,!1),this._isEmpty=!1}_drawCurve(t,e){const i=this._ctx,n=t.endWidth-t.startWidth,s=2*Math.ceil(t.length());i.beginPath(),i.fillStyle=e.penColor;for(let i=0;i<s;i+=1){const o=i/s,h=o*o,r=h*o,a=1-o,d=a*a,l=d*a;let c=l*t.startPoint.x;c+=3*d*o*t.control1.x,c+=3*a*h*t.control2.x,c+=r*t.endPoint.x;let u=l*t.startPoint.y;u+=3*d*o*t.control1.y,u+=3*a*h*t.control2.y,u+=r*t.endPoint.y;const v=Math.min(t.startWidth+r*n,e.maxWidth);this._drawCurveSegment(c,u,v)}i.closePath(),i.fill()}_drawDot(t,e){const i=this._ctx,n=e.dotSize>0?e.dotSize:(e.minWidth+e.maxWidth)/2;i.beginPath(),this._drawCurveSegment(t.x,t.y,n),i.closePath(),i.fillStyle=e.penColor,i.fill()}_fromData(e,i,n){for(const s of e){const{penColor:e,dotSize:o,minWidth:h,maxWidth:r,points:a}=s;if(a.length>1)for(let n=0;n<a.length;n+=1){const s=a[n],d=new t(s.x,s.y,s.pressure,s.time);this.penColor=e,0===n&&this._reset();const l=this._addPoint(d);l&&i(l,{penColor:e,dotSize:o,minWidth:h,maxWidth:r})}else this._reset(),n(a[0],{penColor:e,dotSize:o,minWidth:h,maxWidth:r})}}_toSVG(){const t=this._data,e=Math.max(window.devicePixelRatio||1,1),i=this.canvas.width/e,n=this.canvas.height/e,s=document.createElementNS("http://www.w3.org/2000/svg","svg");s.setAttribute("width",this.canvas.width.toString()),s.setAttribute("height",this.canvas.height.toString()),this._fromData(t,(t,{penColor:e})=>{const i=document.createElement("path");if(!(isNaN(t.control1.x)||isNaN(t.control1.y)||isNaN(t.control2.x)||isNaN(t.control2.y))){const n=`M ${t.startPoint.x.toFixed(3)},${t.startPoint.y.toFixed(3)} C ${t.control1.x.toFixed(3)},${t.control1.y.toFixed(3)} ${t.control2.x.toFixed(3)},${t.control2.y.toFixed(3)} ${t.endPoint.x.toFixed(3)},${t.endPoint.y.toFixed(3)}`;i.setAttribute("d",n),i.setAttribute("stroke-width",(2.25*t.endWidth).toFixed(3)),i.setAttribute("stroke",e),i.setAttribute("fill","none"),i.setAttribute("stroke-linecap","round"),s.appendChild(i)}},(t,{penColor:e,dotSize:i,minWidth:n,maxWidth:o})=>{const h=document.createElement("circle"),r=i>0?i:(n+o)/2;h.setAttribute("r",r.toString()),h.setAttribute("cx",t.x.toString()),h.setAttribute("cy",t.y.toString()),h.setAttribute("fill",e),s.appendChild(h)});const o=`<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 ${this.canvas.width} ${this.canvas.height}" width="${i}" height="${n}">`;let h=s.innerHTML;if(void 0===h){const t=document.createElement("dummy"),e=s.childNodes;t.innerHTML="";for(let i=0;i<e.length;i+=1)t.appendChild(e[i].cloneNode(!0));h=t.innerHTML}return"data:image/svg+xml;base64,"+btoa(o+h+"</svg>")}}return i}));

            jQuery( document ).ready( ($) => {
                function aliSignatureField($scope, $) {
                    var $elements = $scope.find('[data-ali-signature] canvas');

                    if (!$elements.length) {
                        return;
                    }

                    $.each($elements, function (i, $element) {
                        let cachedImage;
                        const signaturePad = new SignaturePad($element, {
                            onEnd: function () {
                                cachedImage = signaturePad.toDataURL('image/ipg');
                            },
                        });

                        const $aliSignature = $($element).closest('[data-ali-signature]'),
                            $clearButton = $aliSignature.find('[data-ali-signature-clear]');

                        $clearButton.click(function () {
                            signaturePad.clear();
                            cachedImage = signaturePad.toDataURL('image/jpg');
                        });
                        signaturePad.addEventListener("endStroke", () => {
                            if (signaturePad.isEmpty()) {
                                $aliSignature.find('.elementor-field').val('');
                            } else {
                                var url = signaturePad.toDataURL();
                                $aliSignature.find('.elementor-field').val(url);
                            }
                        }, { once: false });

                        function resizeCanvas() {
                            if (!cachedImage) return;
                            const ratio = Math.max(window.devicePixelRatio || 1, 1);
                            $element.width = $element.offsetWidth * ratio;
                            $element.height = $element.offsetHeight * ratio;
                            $element.getContext('2d').scale(ratio, ratio);
                            signaturePad.fromDataURL(cachedImage);
                        }

                        var windowWidth = $(window).width();
                        $(window).resize(function () {
                            if ($(window).width() != windowWidth) {
                                window.onresize = resizeCanvas;
                                resizeCanvas();
                            }
                        });
                        Screen.orientation = resizeCanvas;
                        resizeCanvas();
                    });
                }
                aliSignatureField($(document), $);

                elementorFrontend.hooks.addAction('frontend/element_ready/form.default', aliSignatureField);
            });
        </script>
<?php
    }

}
