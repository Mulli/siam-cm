<?php

namespace ElementorControls;

if (!defined('ABSPATH')) exit;

class Ali_Custom_Controls {
    public function __construct() {
            add_action('elementor/controls/controls_registered', [$this, 'register_controls']);

    }

    public function includes() {
        require_once( __DIR__ . '/select-control.php' );
    }

    public function register_controls() {
        $this->includes();
        $controls_manager = \Elementor\Plugin::$instance->controls_manager;
        $controls_manager->register_control(\Elementor\AliCustomControls\Select_Control::Select, new \Elementor\AliCustomControls\Select_Control());

    }



}

new Ali_Custom_Controls();