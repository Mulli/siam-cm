<?php
defined( 'ABSPATH' ) || exit;

class Init {
    public static function add_form_action( $form_actions_registrar ) {
        if(( get_option( 'ali-hubspot-integration', 2 ) == 2 || get_option( 'ali-hubspot-integration', 2 ) == 1 ) && get_option('ali_license_status') == 'valid') {
            require_once(__DIR__ . '/extensions/extension-ali-hubspot.php');
            $form_actions_registrar->register( new Ali_Hubspot() );
        }
        
        if(( get_option( 'ali-brevo-integration', 2 ) == 2 || get_option( 'ali-brevo-integration', 2 ) == 1 ) && get_option('ali_license_status') == 'valid') {
            require_once(__DIR__ . '/extensions/extension-ali-brevo.php');
            $form_actions_registrar->register( new Ali_Brevo() );
        }

        if(( get_option( 'ali-sendy-integration', 2 ) == 2 || get_option( 'ali-sendy-integration', 2 ) == 1 ) && get_option('ali_license_status') == 'valid') {
            require_once(__DIR__ . '/extensions/extension-ali-sendy.php');
            $form_actions_registrar->register( new Ali_Sendy() );
        }

        if(( get_option( 'ali-get-response-integration', 2 ) == 2 || get_option( 'ali-get-response-integration', 2 ) == 1 ) && get_option('ali_license_status') == 'valid') {
            require_once(__DIR__ . '/extensions/extension-ali-get-response.php');
            $form_actions_registrar->register( new Ali_Get_Response() );
        }

        if( (get_option( 'ali-google-sheet-integration', 2 ) == 2 || get_option( 'ali-google-sheet-integration', 2 ) == 1)  && get_option('ali_license_status') == 'valid') {
            require_once(__DIR__ . '/extensions/extension-ali-google-sheet.php');
            $form_actions_registrar->register( new Ali_Google_Sheet() );
        }

        if( (get_option( 'ali-google-calendar-integration', 2 ) == 2 || get_option( 'ali-google-calendar-integration', 2 ) == 1)  && get_option('ali_license_status') == 'valid') {
            require_once(__DIR__ . '/extensions/extension-ali-google-calendar.php');
            $form_actions_registrar->register( new Ali_Google_Calendar() );
        }

        if( (get_option( 'ali-add-id-for-email-submission', 2 ) == 2 || get_option( 'ali-add-id-for-email-submission', 2 ) == 1)  && get_option('ali_license_status') == 'valid') {
            require_once(__DIR__ . '/extensions/extension-ali-add-id-for-email.php');
            $form_actions_registrar->register( new Ali_Add_ID_For_Email );
        }

        if( (get_option( 'ali-register-user', 2 ) == 2 || get_option( 'ali-register-user', 2 ) == 1)  && get_option('ali_license_status') == 'valid') {
            require_once(__DIR__ . '/extensions/extension-ali-register-user.php');
            $form_actions_registrar->register( new Ali_Register_User );
        }
    }

    public static function init_form_field() {
        if( (get_option( 'ali-signature-field', 2 ) == 2 || get_option( 'ali-signature-field', 2 ) == 1 ) && get_option('ali_license_status') == 'valid') {
            require_once(__DIR__ . '/extensions/extension-ali-signature-field.php');
            new Ali_Signature_Field();
        }

        if( (get_option( 'ali-term-field', 2 ) == 2 || get_option( 'ali-term-field', 2 ) == 1 ) && get_option('ali_license_status') == 'valid') {
            require_once(__DIR__ . '/extensions/extension-ali-term-field.php');
            new Ali_Term_Field();
        }
    }

    public static function init_controls() {

        if( (get_option( 'ali-custom-search-results', 2 ) == 2 || get_option( 'ali-custom-search-results', 2 ) == 1)&& get_option('ali_license_status') == 'valid' ) {
            require_once( __DIR__ . '/extensions/extension-ali-custom-search-results.php' );
            new Ali_Custom_Search_Result();
        }

        if( (get_option( 'ali-tooltip', 2 ) == 2 || get_option( 'ali-tooltip', 2 ) == 1)&& get_option('ali_license_status') == 'valid' ) {
            require_once( __DIR__ . '/extensions/extension-ali-tooltip.php' );
            new Ali_Tooltip();
        }

        if( (get_option( 'ali-range-slider', 2 ) == 2 || get_option( 'ali-range-slider', 2 ) == 1)&& get_option('ali_license_status') == 'valid' ) {
            require_once( __DIR__ . '/extensions/extension-ranger-slider-field.php' );
            new Ali_Range_Slider_For_Elementor_Form();
        }

        if( (get_option( 'ali-style-for-elementor-form', 2 ) == 2 || get_option( 'ali-style-for-elementor-form', 2 ) == 1)&& get_option('ali_license_status') == 'valid' ) {
            require_once( __DIR__ . '/extensions/extension-style-for-elementor-form.php' );
            new ALi_Style_For_Elementor_Form();
        }

        if( (get_option( 'ali-mask-for-elementor-form', 2 ) == 2 || get_option( 'ali-mask-for-elementor-form', 2 ) == 1)&& get_option('ali_license_status') == 'valid' ) {
            require_once( __DIR__ . '/extensions/extension-mask-for-elementor-form.php' );
            new Ali_Mask_For_Elementor_Form();
        }

        if( (get_option( 'ali-image-select-field', 2 ) == 2 || get_option( 'ali-image-select-field', 2 ) == 1) && get_option('ali_license_status') == 'valid') {
            require_once( __DIR__ . '/extensions/extension-image-select-field.php' );
            new Ali_Image_Select_Field();
        }

        if( (get_option( 'ali-select2-field', 2 ) == 2 || get_option( 'ali-select2-field', 2 ) == 1)&& get_option('ali_license_status') == 'valid' ) {
            require_once(__DIR__ . '/extensions/extension-ali-select2-field.php');
            new \Elementor\Ali_Select2_Field();
        }

        if( (get_option( 'ali-icon-for-field', 2 ) == 2 || get_option( 'ali-icon-for-field', 2 ) == 1)&& get_option('ali_license_status') == 'valid' ) {
            require_once(__DIR__ . '/extensions/extension-ali-icon-for-field.php');
            new \Elementor\Icons();
        }

        if( (get_option( 'ali-min-max-length', 2 ) == 2 || get_option( 'ali-min-max-length', 2 ) == 1)&& get_option('ali_license_status') == 'valid' ) {
            require_once(__DIR__ . '/extensions/extension-ali-min-max-length.php');
            new \Elementor\Ali_Min_Max_Length_For_Field();
        }

        if( (get_option( 'ali-select-autocomplete', 2 ) == 2 || get_option( 'ali-select-autocomplete', 2 ) == 1 )&& get_option('ali_license_status') == 'valid') {
            require_once(__DIR__ . '/extensions/extension-ali-select-autocomplete.php');
            new \Elementor\Ali_Select_Autocomplete_Field();
        }

        if( (get_option( 'ali-international-tel-field', 2 ) == 2 || get_option( 'ali-international-tel-field', 2 ) == 1)&& get_option('ali_license_status') == 'valid' ) {
            require_once( __DIR__ . '/extensions/extension-ali-international-tel-field.php');
            new Ali_International_Tel_Field();
        }

        if( (get_option( 'ali-calculation', 2 ) == 2 || get_option( 'ali-calculation', 2 ) == 1)&& get_option('ali_license_status') == 'valid' ) {
            require_once( __DIR__ . '/extensions/extension-ali-calculation-for-elementor-form.php');
            new Ali_Calculated_Fields_Form();
        }

        if( (get_option( 'ali-conditional', 2 ) == 2 || get_option( 'ali-conditional', 2 ) == 1)&& get_option('ali_license_status') == 'valid' ) {
            require_once( __DIR__ . '/extensions/extension-ali-conditional-field.php');
            new Ali_Conditional_Logic_Form();
        }

        if( (get_option( 'ali-preview-form-data', 2 ) == 2 || get_option( 'ali-preview-form-data', 2 ) == 1)&& get_option('ali_license_status') == 'valid' ) {
            require_once( __DIR__ . '/extensions/extension-ali-preview-data.php');
            new Ali_Preview_Data();
        }
    }
}